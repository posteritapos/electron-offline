angular.module('app').controller("MainController", function($scope, $location, $state, LoginService, CommissionService, ClockInOutService) {
	
	$scope.requestPin = function(callback){
		
		$scope.pin(function(pin){
			
			//validate PIN			
			var user = APP.USER.getUserByPin(pin);						
			
			if(user == null){
				alert("Invalid PIN!");
			}
			else
			{
				var role = APP.ROLE.getRoleById(user.ad_role_id);
				
				//check if clock in
				if( ClockInOutService.isUserClockedIn( user.ad_user_id ) ){							
					
					LoginService.user = user;
					LoginService.role = role;
					CommissionService.setActive(user.ad_user_id);
					
					callback(user, role);					
				}
				else
				{
					alert("User not clocked-in!");
				}				
				
			}
			
		});
		
	};
	
	$scope.validatePath = function(path, params){	
		
		console.log('Validating path -> ' + path);
		
		$scope.requestPin(function(){
			$state.go(path, params);
		});		
	};
});