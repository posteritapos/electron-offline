angular.module('app').controller("SplashController", function($scope, $location, LoginService, CustomerService)
{
	$scope.showModal();
	APP.initCache().done(function()
	{
		var terminal = APP.TERMINAL.searchTerminals({})[0];
		var store = APP.STORE.getStoreById(terminal.ad_org_id);
		LoginService.terminal = terminal;
		LoginService.store = store;
		var customer = APP.BP.getBPartnerById(terminal['c_bpartner_id']);
		CustomerService.setDefaultCustomer(customer);
		$scope.$apply(function()
		{
			$location.path("/login");
			$scope.closeModal();
		});
	}).fail(function(msg){
		//failed to create
		$scope.alert(msg);
		
	}).always(function()
	{
		$scope.closeModal();
	});
});