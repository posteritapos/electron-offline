angular.module('app').service('LoginService', function(){
	
	var service = this;
	
	service.login = function( username, password ){
		//todo		
	};
	
	service.logout = function(){
		//todo		
	};
	
});