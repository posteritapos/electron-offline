angular.module('app').service('OrderScreenService', function(){
	
	var screen = this;
	
	screen.bp = null;
	screen.sales_rep = null;
	screen.commissions = [];
	screen.comments = null;
	
});