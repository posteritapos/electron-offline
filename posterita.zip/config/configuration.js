const { app } = require('electron')
const path = require('path')
const fs = require('fs')
const axios = require("axios")

const Configuration = {

    constants : {
        "SERVER_ADDRESS" : "server-address",
        "DOMAIN" : "domain",
        "MERCHANT_KEY" : "merchant-key",
        "TERMINAL_KEY" : "terminal-key",
        "CONFIG_FILENAME" : "config.json"
    },

    getConfigurationFilePath : function(){
        let configFilePath = path.join(app.getAppPath(), this.constants.CONFIG_FILENAME);
        return configFilePath;
    },   

    isConfigured : function(){

        let configFilePath = this.getConfigurationFilePath();

        if (fs.existsSync(configFilePath)) 
        {   
            return true;
        }
        else 
        {
            console.log(`File ${configFilePath} not found!`);
            return false;
        }
    },

    get : function(){

        if(this.isConfigured()){

            try 
            {
                const data = fs.readFileSync(this.getConfigurationFilePath(), 'utf8')
                return JSON.parse(data);
              
            } catch (err) 
            {
                console.error(err);
                throw err;
              
            }            
        }

        return null;
    },

    save : async function(config){

        let filePath = this.getConfigurationFilePath();

        let promise = new Promise(function (resolve, reject) {

            fs.writeFile(filePath, JSON.stringify(config), 'utf8', function (err) {
                if (err) {
                    console.log("An error occured while saving config.");
                    reject(err);
                }
    
                console.log("Saved config file.");
                resolve(config);
            });

        });

        return promise;
        
    },

    test : function(config){

        let promise = new Promise(function (resolve, reject) {

            if(!config){
                reject("Config parameter not found!");
                return;
            }

            //test server url
            let server_address = config[Configuration.constants.SERVER_ADDRESS];
            let merchant_key = config[Configuration.constants.MERCHANT_KEY];
            let terminal_key = config[Configuration.constants.TERMINAL_KEY];

            let url = `${server_address}/OfflineDataAction.do?action=testConfiguration&merchantKey=${merchant_key}&terminalKey=${terminal_key}`;

            axios.get(url, {timeout: 10 * 1000}).then(response => {

                let result = response.data;

                if(result.status == 'error'){
                    reject(result['error-message']);
                    return;
                }

                resolve(result);

            }).catch(error => {
                console.error(error);
                reject("Failed to connect to " + server_address);
            });           

        });  
        
        return promise;

    }    
};

module.exports = Configuration;