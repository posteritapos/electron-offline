const axios = require("axios");
const path = require("path");
const { app } = require('electron');

const Database = require("./database");
const moment = require("moment");
const config = require(path.join(app.getAppPath(), "config.json"));

var synchronizer = {

    addListener: function (listener) {
        this.listener = listener;
    },

    status: function (status) {
        console.log(status);
        if (this.listener) this.listener(status);
    },

    pullData: async function () {

        const AdmZip = require('adm-zip');

        let serverURL = config["server-address"];
        let merchantKey = config["merchant-key"];
        let terminalKey = config["terminal-key"];

        let file_url = `${serverURL}/OfflineDataAction.do?action=pullData&api-key=${merchantKey}&terminal-key=${terminalKey}`;

        let synchronizer_ref = this;

        synchronizer_ref.status("Creating product price backup ...");
        await synchronizer_ref.backupProductPrice();

        synchronizer_ref.status("Requesting latest data ...");

        //TODO: fix race condition between tables

        let importData = function (table, data) {

            return new Promise(async (resolve, reject) => {

                try {

                    if (data.error) {
                        var msg = `Failed to update table ${table}. The server return the following error: ${data.error}`;
                        synchronizer_ref.status(msg);
                        reject(msg);
                        return;
                    }

                    let records = data.records;

                    synchronizer_ref.status(`Updating table ${table}. ${records.length} records found`);

                    let freshDB = false;

                    if (table == "TERMINAL") {
                        						
						let record;
						
                        for(let i=0; i<records.length; i++)	{						
							record = records[i];	
							await Database.put(table, record, "id");
						}

                        //clear previous configured terminal
                        await Database.executeUpdate("delete from TERMINAL where id <> ? ", [terminalKey]);
                    }
                    else if (table == "PRODUCT_PRICE") {
                        await synchronizer_ref.initProductPrice(records);
                    }
                    else if (table == "ATTRIBUTESET_INSTANCE") {
                        await synchronizer_ref.initAttributeSetInstance(records);
                    }
                    else {

                        await Database.putAll(table, data.records, "id");

                    }

                    /*
                    if (table == "PRODUCT") {
                        // build search tables
                        synchronizer_ref.status("Initializing search tables ...");
                        await synchronizer_ref.initSearchProduct(records)
                        //synchronizer_ref.status(await synchronizer_ref.initSearchProduct(records));

                        synchronizer_ref.status("Looking for price changes ...");
                        await synchronizer_ref.initProductUpdate()
                        //synchronizer_ref.status(await synchronizer_ref.initProductUpdate());

                    }
                    */

                    await Database.executeUpdate("DELETE FROM SYNC_DATE WHERE EVENT = ?", [table]);
                    await Database.executeUpdate("INSERT INTO SYNC_DATE(EVENT, EVENTDATE) VALUES(?,?)", [table, moment().format("YYYY-MM-DD HH:mm:ss")]);

                    synchronizer_ref.status(`Updated table ${table}`);
                    console.log(`Updated table ${table}`);
                    resolve(`Updated table ${table}`);

                }
                catch (e) {
                    reject(e);
                }
            });

        }

        let request_promise = new Promise(async (resolve, reject) => {			
			
			axios.get(file_url, {

                onDownloadProgress: function (axiosProgressEvent) {
                    synchronizer_ref.status(Math.round(axiosProgressEvent.progress * 100) + "% | " 
                    + Math.round(axiosProgressEvent.loaded / 1024) + " KB downloaded out of " 
                    + Math.round(axiosProgressEvent.total / 1024) + " KB.");
                },

                responseType: 'stream'

            }).then(function (response) {

                const _buf = [];

                const stream = response.data;
                stream.on("data", (chunk) => _buf.push(chunk));
                stream.on("end", () => {

                    let body = Buffer.concat(_buf);

                    var zip = new AdmZip(body);
	                var zipEntries = zip.getEntries();
	
	                let promises = [];
	
	                zipEntries.forEach((entry) => {
	
	                    console.log(`Importing ${entry.entryName}`);
	
	                    let table = entry.entryName.toUpperCase();
	                    let data = zip.readAsText(entry);
	                    data = JSON.parse(data);
	
	                    console.log(`==> ${table}`);
	                    promises.push(importData(table, data));
	
	                });
	
	                Promise.all(promises).then(async function (values) {
	                    console.log(values);
	                    //synchronizer_ref.status("Updated local database successfully");
	
	                     // build search tables
	                     let products = await Database.getAll("PRODUCT");
	
	                     synchronizer_ref.status("Initializing search tables ...");
	                     await synchronizer_ref.initSearchProduct(products);
	
	                     synchronizer_ref.status("Looking for price changes ...");
	                     await synchronizer_ref.initProductUpdate();
	
	                    resolve();
	                });

                });
                stream.on("error", (err) => reject(err));

            }).catch(function (error) {
				console.error(error);
                reject(error.message);
            });
            
        });

        console.log("waiting for synchronizer to complete ...");
        await request_promise;

        await this.setSyncDate('SYSTEM');
        console.log("Synchronizer completed!");


    },

    synchronizeDocumentNo: async function (updateDocumentNo, endpoint) {

        let terminal_id = config["terminal-key"];
        let terminals = await Database.getSqlValues("select id, sequence_no sequence from terminal", []);

        let serverURL = endpoint || config["server-address"];

        let url = `${serverURL}/OfflineDataAction.do`;

        let form = {
            "action": "syncDocumentNo",
            "json": JSON.stringify(terminals)
        };

        let synchronizer_ref = this;

        let request_promise = new Promise(async (resolve, reject) => {

            try {
				
				axios.post(url, form, { headers : {"content-type": "application/x-www-form-urlencoded"}}).then( async function (response) {
					
					let results = response.data;

                    for (let result of results) {

                        let id = result["id"];
                        let sequence = result["sequence"];
                        let sequence_on_server = result["sequence_on_server"];
                        let updated = result["updated"];
                        let sequence_prefix = "";

                        if (result["sequence_prefix"]) {
                            sequence_prefix = result["sequence_prefix"];
                        }

                        console.log(`Terminal ID: ${id}, Sequence: ${sequence}, Sequence on server: ${sequence_on_server}, Updated: ${updated}`); //, id, sequence, sequence_on_server, updated));


                        if (updateDocumentNo == true) {
                            // update terminal sequence
                            let x = await Database.executeUpdate("update terminal set SEQUENCE_NO = ? where id = ? ", [sequence_on_server, id]);
                            console.log(`Update, Terminal ID: ${id}. ${x}`);

                            if (sequence_prefix != null) {
                                await Database.executeUpdate("update terminal set SEQUENCE_PREFIX = ? where id = ? ", [sequence_prefix, id]);
                            }

                            console.log(`Update, Terminal ID: ${id}, Sequence: ${sequence_on_server}`);
                        }
                    }

                    await synchronizer_ref.setSyncDate('TERMINAL');

                    console.log("synchronized document no");

                    resolve("synchronized document no");
                    
				}).catch(function (error) {
					console.error(error);
					reject("Failed to synchronized document no. " + error.message);
				});
				
            }
            catch (e) {
                reject(e);
            }

        });

        return request_promise;

    },

    synchronizeOrders: async function (test, minutes, auto) {

        let synchronizer_ref = this;

        console.log("Synchronizing orders ...");
        console.log("Quering orders ..");

        let sync_promise = new Promise(async (resolve, reject) => {

            let batch = [];
            let MAX_ORDERS = 100;
            let count = 0;            

            let sql = " select value, tendertype, docstatus from orders where status in ('', 'DR','IP', 'RP') order by date_ordered desc";		
			
            let records = await Database.getSqlValues(sql, []);

            let sb = "[";

            let value, tendertype, docstatus;
            let isDraftOrOpen = false;
            //order marked for synchronization when till is closed.
			let pushDraftAndOpenOrders = false;

            let order = null;

            for (let record of records) {

                value = record["value"];
                tendertype = record["tendertype"];
                docstatus = record["docstatus"];

                order = JSON.parse(value);

                //look for flag pushDraftAndOpenOrders
				isDraftOrOpen = false;
				pushDraftAndOpenOrders = order["pushDraftAndOpenOrders"] || false;

                if ("DR" == docstatus) {
                    console.log("Found drafted order ...");	
                    isDraftOrOpen = true;
                }
                else if ("Mixed" == tendertype) {

                    let openAmt = order["grandTotal"];

                    let payments = order["payments"];

                    for (let payment of payments) {
                        openAmt = openAmt - payment["payAmt"];
                    }

                    if (openAmt != 0) {
                        console.log("Found open order ...");
                        isDraftOrOpen = true;
                    }
                }

                if( isDraftOrOpen && !pushDraftAndOpenOrders) {
					continue;
				}

                count++;


                if (count % MAX_ORDERS == 0) {
                    sb += "]";
                    batch.push(sb);

                    sb += "[";
                }


                if (sb.length > 1) {
                    sb += ",";
                }

                sb += value;

            }

            sb += "]";
            batch.push(sb);

            if (count == 0) {

                console.log("No new order found, returning ...");

                resolve(count);
                return;

            }

            console.log(`Synchronizing ${count} orders`);

            let responseJSON = null;
            let batchCount = 0;

            const serverURL = config["server-address"];
            const merchantKey = config["merchant-key"];
            const terminalKey = config["terminal-key"];

            let url = `${serverURL}/OfflineDataAction.do`;
            const action = test ? "testSyncOrders" : "syncOrders";

            let postBatch = function(form){

                return new Promise(function(resolve, reject) {

                    let db = Database.getDatabase();
                    
                    axios.post(url, form, { headers : {"content-type": "application/x-www-form-urlencoded"}}).then( async function (response) {
						
						let results = response.data;
                
                        let status = null;
                        let uuid = null;
                        let error = null;
                        let orderId = null;
                        let order = null;
        
                        let value = null;
        
                        let sql = "BEGIN TRANSACTION;";
        
                        for (let result of results) {                        
        
                            error = null;
                            orderId = null;
        
                            uuid = result["uuid"];
                            status = result["status"];
        
                            order = await Database.get("ORDERS", uuid);
                            order["status"] = status;
        
                            if ("ER" == status) {
                                error = result["errorMsg"];
                                order["errormsg"] = error;
                            }
                            else {
                                orderId = result["orderId"];
        
                                if (orderId != undefined) {
                                    order["orderId"] = orderId;
                                }
                            }
        
                            value = JSON.stringify(order);
        
                            value = value.replace(/\'/g,"''");
                            sql += `UPDATE ORDERS SET VALUE = '${value}', STATUS = '${status}', ERROR_MESSAGE = '${error}' WHERE ID = '${uuid}';`;
        
                        }
        
                        sql += "COMMIT;";
        
                        db.exec(sql, function (err) {
        
                            if (err) {
                                console.log(err);
                                reject(err);
                            }
    
                            resolve("Updated orders");
    
                        });
						
					}).catch(function (error) {
						console.log(error);
						reject("Failed to push orders " + error.message);
					});
            
                });                
            
            }

            let promises = [];

            for (let b of batch) {

                ++batchCount;

                console.log(`Pushing batch  ${batchCount}`);

                let batchPostPayload = {
                    "merchantKey": merchantKey,
                    "terminalKey": terminalKey,
                    "action": action,
                    "json": b
                };

                promises.push(postBatch(batchPostPayload));
                
            }//batch

            Promise.all(promises).then(async function (values) {

                console.log(values);

                console.log(`Synchronized ---> ${count} orders`);

                await synchronizer_ref.setSyncDate('ORDERS');

                resolve(count);
            });           

        });

        return sync_promise;
    },

    synchronizeClockInOut: async function () {

        console.log("Synchronizing clock ins and outs ...");

        let sync_promise = new Promise(async (resolve, reject) => {

            let clockinouts = await Database.getSqlValues("select user_id, terminal_id, time_in, time_out, uuid, synchronized from clock_in_out where synchronized = 'N'", []);

            if (clockinouts.length == 0) {
                resolve(true);
            }

            console.log("Pushing clock ins and outs ..");

            let serverURL = config["server-address"];
            let merchantKey = config["merchant-key"];
            let terminalKey = config["terminal-key"];

            let url = `${serverURL}/OfflineDataAction.do`;

            let form = {
                "merchantKey": merchantKey,
                "terminalKey": terminalKey,
                "action": "syncClockInOut",
                "json": JSON.stringify(clockinouts)
            };

            let synchronizer_ref = this;

            try {
								
				axios.post(url, form, { headers : {"content-type": "application/x-www-form-urlencoded"}}).then( async function (response) {
					
					let results = response.data;

                    let array = [];

                    for (let result of results) {
                        let { uuid, synchronized, errorMsg } = result;

                        //do bulk update
                        if (synchronized == true) {
                            //await Database.executeUpdate("UPDATE CLOCK_IN_OUT SET SYNCHRONIZED = 'Y' WHERE UUID = ? ", [uuid]);
                            array.push(uuid);
                        }
                        else {
                            console.log(`Error ---> ${errorMsg}`);
                        }
                    }

                    let uuids = "";
                    if(array.length > 0){
                        uuids = "'" + array.join("','") + "'";
                        await Database.executeUpdate("UPDATE CLOCK_IN_OUT SET SYNCHRONIZED = 'Y' WHERE UUID in (" + uuids + ")");
                    }
					
				}).catch(function (error) {
					console.log(error);
					reject("Failed to push clock ins/outs " + error.message);
				});

            } catch (error) {

                reject(error);                
            }

            resolve(true);

        });

        return sync_promise;
    },

    synchronizeCloseTill: async function () {

        console.log("Synchronizing close tills ...");

        let sync_promise = new Promise(async (resolve, reject) => {

            try {

                let closetills = await Database.getSqlValues("select json from close_till where synchronized = 'N' and time_close is not null", []);

                if (closetills.length == 0) {
                    resolve(true);
                }

                let x = "[";

                for(let till of closetills){

                    if(x.length > 1) x += ",";

                    x += till["json"];
                }

                x += "]";

                console.log("Pushing close tills ..");

                let serverURL = config["server-address"];
                let merchantKey = config["merchant-key"];
                let terminalKey = config["terminal-key"];

                let url = `${serverURL}/OfflineDataAction.do`;

                let form = {
                    "merchantKey": merchantKey,
                    "terminalKey": terminalKey,
                    "action": "syncCloseTill",
                    "json": x
                };

                let synchronizer_ref = this;
                
                axios.post(url, form, { headers : {"content-type": "application/x-www-form-urlencoded"}}).then( async function (response) {
					
					let results = response.data;

                    for (let result of results) {
                        let { uuid, synchronized, errorMsg } = result;

                        if (synchronized == true) {
                            await Database.executeUpdate("UPDATE CLOSE_TILL SET SYNCHRONIZED = 'Y' WHERE UUID = ? ", [uuid]);
                        }
                        else {
                            console.log(`Error ---> ${errorMsg}`);
                        }
                    }

                    resolve(true);
					
				}).catch(function (error) {
					console.log(error);
					reject("Failed to push close tills. " + error.message);
				});                
                
            } catch (error) {
                reject(error);
            }

        });

        return sync_promise;      

    },

    synchronizeCashierControl: async function (json) {

        console.log("Synchronizing cashier control ...");

        console.log("Pushing cashier controls ...");

        let sync_promise = new Promise(async (resolve, reject) => {

            let serverURL = config["server-address"];
            let merchantKey = config["merchant-key"];
            let terminalKey = config["terminal-key"];

            let url = `${serverURL}/OfflineDataAction.do`;

            let form = {
                "merchantKey": merchantKey,
                "terminalKey": terminalKey,
                "action": "syncCashierControl",
                "json": JSON.stringify(json)
            };

            let synchronizer_ref = this;

            try {
				
				axios.post(url, form, { headers : {"content-type": "application/x-www-form-urlencoded"}}).then( async function (response) {
					
					let results = response.data;

                    for (let result of results) {
                        let { uuid, synchronize, errorMsg } = result;

                        if (synchronize == true) {
                            await Database.executeUpdate("UPDATE CASHIER_CONTROL SET SYNCHRONIZED = 'Y' WHERE UUID = ? ", [uuid]);
                        }
                        else {
                            console.log(`Error ---> ${errorMsg}`);
                        }
                    }

                    resolve("synchronized");
					
				}).catch(function (error) {
					console.log(error);
					reject("Failed to push cashier controls. " + error.message);
				});
				
            } catch (error) {
                reject(error);
            }

        });

        return sync_promise;

    },

    initSearchProduct: async function (records) {

        this.status("Initializing product search ...");

        let db = Database.getDatabase();
        let table = "search_product";

        const promise = new Promise(function (resolve, reject) {

            try {

                db.serialize(function () {

                    db.run(`DELETE FROM ${table}`, function (err) {
                        console.log(`Clean table [${table}]`);
                    });

                    db.run("BEGIN TRANSACTION");

                    let stmt = db.prepare(`INSERT INTO ${table}(
                        m_product_id, 
                        m_product_parent_id, 
                        name, 
                        description, 
                        upc, 
                        sku, 
                        primarygroup, 
                        productcategory, 
                        group1, 
                        group2, 
                        group3, 
                        group4, 
                        group5, 
                        group6, 
                        group7, 
                        group8, 
                        json, 
                        ismodifier,
                        extendeddescription )
                        VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )`);

                    for (let record of records) {

                        stmt.run(
                            record.m_product_id,
                            record.m_product_parent_id,
                            record.name,
                            record.description,
                            record.upc,
                            record.sku,
                            record.primarygroup,
                            record.productcategory,
                            record.group1,
                            record.group2,
                            record.group3,
                            record.group4,
                            record.group5,
                            record.group6,
                            record.group7,
                            record.group8,
                            null,
                            record.ismodifier,
                            record.extendeddescription
                        );

                    }

                    stmt.finalize();

                    db.run("COMMIT");

                    var msg = `Inserted ${records.length} records into table [${table}]`;
                    resolve(msg);
                    console.log(msg);

                });

            }
            catch (e) {
                reject(err);
                console.log(err);
            }

        });

        return promise;
    },

    initProductUpdate: async function () {

        console.log("Initializing product update ...");

        let date_updated = moment().format('YYYY-MM-DD HH:mm:ss');

        let terminal_id = config["terminal-key"];
        let terminal = await Database.get("TERMINAL", terminal_id);

        if(terminal == null) return;

        let m_pricelist_id = terminal["m_pricelist_id"];

        let sql = `insert into product_updated( m_product_id, name, description, upc, sku, old_price, new_price, date_updated ) 
        select search_product.m_product_id, search_product.name, search_product.description, search_product.upc, 
        search_product.sku, product_price_2.pricestd as old_price, product_price.pricestd as new_price, '${date_updated}' as date_updated  
        from product_price_2, product_price, search_product  
        where product_price_2.m_pricelist_id = product_price.m_pricelist_id 
        and product_price_2.m_product_id = product_price.m_product_id 
        and search_product.m_product_id = product_price_2.m_product_id 
        and product_price_2.pricestd != product_price.pricestd 
        and product_price_2.m_pricelist_id = ${m_pricelist_id}`;

        await Database.executeUpdate(sql, []);

        console.log("Initialized product_updated");
        this.status("Initialized product_updated");
    },

    initProductPrice: async function (records) {
        this.status("Initializing product price ...");

        let db = Database.getDatabase();
        let table = "product_price";

        const promise = new Promise(function (resolve, reject) {

            db.serialize(function () {

                db.run(`DELETE FROM ${table}`, function (err) {
                    console.log(`Clean table [${table}]`);
                });


                let sql = "BEGIN TRANSACTION;";

                for (let record of records) {

                    sql += `INSERT INTO ${table}(m_product_id, m_pricelist_id, pricelist, pricestd, pricelimit) VALUES (${record.m_product_id}, ${record.m_pricelist_id}, ${record.pricelist}, ${record.pricestd}, ${record.pricelimit});`;

                }

                sql += "COMMIT;";
                db.exec(sql, function (err) {

                    if (err) {
                        reject(err);
                        console.log(err);
                    }
                    else {
                        var msg = `Inserted ${records.length} records into table [${table}]`;
                        resolve(msg);
                        console.log(msg);
                    }

                });

            });

        });

        return promise;

    },

    initAttributeSetInstance : async function (records) {
        this.status("Initializing attributeset instances ...");

        let db = Database.getDatabase();
        let table = "attributeset_instance";

        const promise = new Promise(function (resolve, reject) {

            db.serialize(function () {

                db.run(`DELETE FROM ${table}`, function (err) {
                    console.log(`Clean table [${table}]`);
                });


                let sql = "BEGIN TRANSACTION;";

                for (let record of records) {

                    sql += `INSERT INTO ${table}(m_attributesetinstance_id, m_attributeset_id, description, lot, expirydate) VALUES (${record.m_attributesetinstance_id}, ${record.m_attributeset_id}, '${record.description}', '${record.lot}', '${record.expirydate}');`;

                }

                console.log(sql);

                sql += "COMMIT;";
                db.exec(sql, function (err) {

                    if (err) {
                        reject(err);
                        console.log(err);
                    }
                    else {
                        var msg = `Inserted ${records.length} records into table [${table}]`;
                        resolve(msg);
                        console.log(msg);
                    }

                });

            });

        });

        return promise;
    },

    setSyncDate: async function (syncEvent) {
        return await Database.executeUpdate("update SYNC_DATE set EVENTDATE = ? where upper(EVENT) = ? ", [ moment().format("YYYY-MM-DD HH:mm:ss"), syncEvent.toUpperCase() ]);
    },

    backupProductPrice: async function () {

        let name = await Database.getSqlValue("select name from sqlite_master where type = 'table' and upper(name) = upper(?)", ["product_price_2"]);

        if (name) {

            console.log("Creating product price backup ...");
            await Database.executeUpdate("delete from product_price_2", []);
            await Database.executeUpdate("insert into product_price_2 select * from product_price", []);
            console.log("Product price backup completed.");

            return true;

        }

        return false;
    }

};

module.exports = synchronizer;

