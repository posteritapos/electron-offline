const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { app } = require('electron');
const moment = require('moment');

sqlite3.Database.prototype.runAsync = function (sql, params) {
    return new Promise((resolve, reject) => {
        this.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve(this);
        });
    });
};

sqlite3.Database.prototype.getAsync = function (sql, params) {

	//console.log("**** > " + sql + "[" + params.join(",") + "]");

    return new Promise((resolve, reject) => {
        this.get(sql, params, function (err, row) {
            if (err) return reject(err);
            resolve(row);
        });
    });
};

sqlite3.Database.prototype.allAsync = function (sql, params) {

	console.log("**** > " + sql + "[" + params.join(",") + "]");

    return new Promise((resolve, reject) => {
        this.run(sql, params, function (err, rows) {
            if (err) return reject(err);
            resolve(rows);
        });
    });
};

sqlite3.Database.prototype.runBatchAsync = function (statements) {
    var results = [];
    var batch = ['BEGIN', ...statements, 'COMMIT'];
    return batch.reduce((chain, statement) => chain.then(result => {
        results.push(result);
        return this.runAsync(...[].concat(statement));
    }), Promise.resolve())
    .catch(err => this.runAsync('ROLLBACK').then(() => Promise.reject(err +
        ' in statement #' + results.length)))
    .then(() => results.slice(2));
};

var database = {

	handle : null,
    
    initialize : function () { 

		this.getDatabase();

		console.info("Initializing database ...");
		
		return this.createTables();
    },

    getDatabase : function(){

		if(this.handle == null){

			this.handle = new sqlite3.Database(this.getDatabasePath());
		}

        return this.handle;

	},

	getDatabasePath : function(){

		let config = require(path.join(app.getAppPath(), "config.json"));

		let serverAddress = config["server-address"];

		const url = require('url');
		const myURL = new URL(serverAddress);

		const hostname = myURL.hostname;
		const domain = config.domain;
	
		const platform = require("os").platform();
	
		let dir = "";
	
		if("win32" == platform){
			dir = path.join(app.getPath("appData"), "posterita");
		}
		else if("linux" == platform){
			dir = path.join(app.getPath("home"), ".posterita");
		}
		else if("darwin" == platform){
			dir = path.join(app.getPath("home"), "/Library/Application Support/posterita");
		}    
		else{
	
		}
	
		dir = path.join(dir, "db", hostname.replace(/\./g,"_"));

		const fs = require('fs');

		if (!fs.existsSync(dir)) {
			fs.mkdirSync(dir, { recursive: true });
		}		

		dir = path.join(dir, domain.replace(/\./g,"_") + ".sqlite");
	
		console.log(dir);

		return dir;
	},

	get : function(table, id){

		table = table.toUpperCase();

		let db = this.getDatabase();

		const promise = new Promise(function(resolve, reject) {	
			
			let isKeyValue = true;

			let sql = "SELECT * FROM " + table + " where id = ?";

			if(table == 'CLOCK_IN_OUT' || table == 'CLOSE_TILL'){

				sql = "SELECT * FROM " + table + " where uuid = ?";

				isKeyValue = false;

			}
			
			db.get(sql, [id], function(err, row) {
			
				if(err){
					reject(err);
				}
				else
				{
					if(isKeyValue && row){
						resolve(JSON.parse(row['VALUE'] || row['value']));
					}
					else
					{
						resolve(row);
					}
					
				}
			});

		});	
		
		return promise;

	},

	getAll : function(table, whereClause){

		table = table.toUpperCase();

		console.log(`Retrieving values [${table}]`);

		let db = this.getDatabase();

		let ref = this;

		const promise = new Promise(function(resolve, reject) {

			let sql;

			let isKeyValue = ref.isKeyValue( table );

			if( isKeyValue ){

				sql = "SELECT value FROM " + table ;

			}
			else
			{
				sql = "select * from " + table;
			}

			if( whereClause ){

				sql = sql + whereClause;

			}

			if(table == "CLOSE_TILL"){
				sql = sql + " order by  TIME_OPEN desc";
			}
			
			if(table == "CLOCK_IN_OUT"){
				sql = sql + " order by  TIME_IN desc";
			}
			
			if(table == "OPEN_DRAWER"){
				sql = sql + " order by  DATE_OPENED desc";
			}
			
			if(table == "RE_PRINT"){
				sql = sql + " order by  DATE_PRINTED desc";
			}
			
			if(table == "PRODUCT_UPDATED"){
				sql = sql + " order by  NAME asc, DATE_UPDATED desc";
			}
			
			
			console.log(sql);

			db.all(sql , [], function(err, rows) {
				
				if(err){
					reject(err);
				}
				else
				{
					if(isKeyValue){

						var parsed = [];
						var row;

						for(var i=0; i<rows.length; i++){

							row = rows[i];

							try 
							{								
								parsed.push(JSON.parse(row['VALUE'] || row['value']));

							} catch (error) 
							{
								console.log("Failed to parse: " + row['VALUE']);
								console.error(error);
							}							

						}

						resolve(parsed);

					}
					else
					{
						resolve(rows);
					}
					
				}
			});

		});	

		return promise;

	},
	
	close : function(){

		console.info("Closing database ...");

		if(this.handle != null){
			this.handle.close((err) => {
				if (err) {
				  return console.error(err.message);
				}
				console.log('Close the database connection.');
			  });
			this.handle == null;
		}

	},

    createTables : function(){

        var tables = [];

        tables.push("ORDERS");
		tables.push("SYSTEM");
		tables.push("USERS");
		tables.push("ROLE");
		tables.push("ROLE_ORG_ACCESS");
		tables.push("TERMINAL");
		tables.push("BOM");
		tables.push("BP");
		tables.push("TAX");
		tables.push("MODIFIER_GROUP");
		tables.push("PRODUCT_MODIFIER_GROUP");
		tables.push("PRODUCT");
		
		//normal tables
		tables.push("CLOCK_IN_OUT");
		tables.push("CLOSE_TILL");
		
		//search table
		tables.push("SEARCH_PRODUCT");
		
		//sync tables
		tables.push("SYNC_LOGS");
		tables.push("SYNC_DATE");
		
		//more tables
		tables.push("STORE");
		tables.push("WAREHOUSE");
		
		//more tables
		tables.push("OPEN_DRAWER");
		tables.push("RE_PRINT");		
		tables.push("PRODUCT_UPDATED");
		tables.push("CART_LOG");	
		tables.push("CASHIER_CONTROL");
		tables.push("PRODUCT_PRICE");
		tables.push("PRODUCT_PRICE_2");
		
		tables.push("PURCHASE");
		tables.push("ORDER_LOG");
		tables.push("ATTRIBUTESET_INSTANCE");
		
		//get database refer
		var db = this.getDatabase();

		const promise = new Promise(function(resolve, reject) {

			db.serialize(async function() {

				var table;

				let existing_tables = [];
				
				db.all("select upper(name) as name from sqlite_master where type = 'table'", function(err, rows) {
	
					for(let row of rows){
						existing_tables.push(row["name"]);
					}

					for( var i=0; i<tables.length; i++){
	
						table = tables[i];
	
						//skip existing tables
						if( existing_tables.indexOf(table) >=0 ) continue;
						
						console.info("Creating table " +  table);				
							
						if(table == "TERMINAL")
						{
							db.run("create table if not exists terminal ("
									+ " id text not null, "
									+ " value text,  "
									+ " sequence_no integer default 0,  "
									+ " sequence_prefix text)");
						}
						else if(table == "ORDERS")
						{
							db.run("create table if not exists orders ("
									+ " id text not null, "
									+ " value text, "
									+ " status text, "
									+ " error_message text, "
									+ " terminal_id integer, "
									+ " store_id integer, "
									+ " customer_id integer, "
									+ " user_id integer, "
									+ " docstatus text, "
									+ " ordertype text, "
									+ " tendertype text, "
									+ " documentno text, "
									+ " date_ordered text)");
						}
						else if(table == "CLOCK_IN_OUT")
						{
							db.run("create table if not exists clock_in_out ("
									+ " user_id integer,"
									+ " terminal_id integer,"
									+ " time_in text,"
									+ " time_out text,"
									+ " uuid text,"
									+ " synchronized text default 'N'"
									+ ")");
						}
						else if(table == "CLOSE_TILL")
						{
							db.run("create table if not exists close_till ("
									+ " open_user_id integer,"
									+ " close_user_id integer,"
									+ " terminal_id integer,"
									+ " time_open text,"
									+ " time_close text,"
									+ " opening_amt real default 0,"
									+ " closing_amt real default 0,"
									+ " cash real default 0,"
									+ " card real default 0,"
									+ " cheque real default 0,"
									+ " gift real default 0,"
									+ " voucher real default 0,"
									+ " ext_card real default 0,"
									+ " loyalty real default 0,"
									+ " coupon real default 0,"
									+ " deposit real default 0,"
	
									+ " mcbjuice real default 0,"
									+ " mytmoney real default 0,"
									+ " emtelmoney real default 0,"
									+ " giftsmu real default 0,"
	
									+ " uuid text,"
									+ " json text, "
									+ " synchronized text default 'N'"
									+ " )");
						}
						else if(table == "SEARCH_PRODUCT")
						{
							db.run("create table if not exists search_product ("
									+ " m_product_id int,"
									+ " m_product_parent_id int,"
									+ " name text,"
									+ " description text,"
									+ " upc text,"
									+ " sku text,"
									+ " primarygroup text,"
									+ " productcategory text,"
									+ " group1 text,"
									+ "	group2 text,"
									+ "	group3 text,"
									+ "	group4 text,"
									+ "	group5 text,"
									+ "	group6 text,"
									+ "	group7 text,"
									+ "	group8 text,"
									+ " json text,"
									+ " ismodifier text,"
									+ " extendeddescription text"
									+ "); create index if not exists upcindex on search_product(upc);");										
							
						}
						else if(table == "SYNC_DATE")
						{
							db.serialize(function() {
								
								db.run("create table if not exists sync_date ("
										+ " event text,"
										+ " eventdate text" 
										+ " )");
								
								var date = moment().format("YYYY-MM-DD HH:mm:ss");
								
								db.run(`insert into sync_date (event, eventdate) values ('orders', '${date}')`);
								db.run(`insert into sync_date (event, eventdate) values ('system', '${date}')`);
								db.run(`insert into sync_date (event, eventdate) values ('terminal', '${date}')`);
								db.run(`insert into sync_date (event, eventdate) values ('clock_inout', '${date}')`);
								db.run(`insert into sync_date (event, eventdate) values ('close_till', '${date}')`);
								
							});		
							
						}
						else if(table == "OPEN_DRAWER")
						{
							db.run("create table if not exists open_drawer ("
									+ " uuid text not null,"
									+ " user_id integer,"
									+ " terminal_id integer,"
									+ " reason text,"
									+ " date_opened text" 
									+ " )");
						}
						else if(table == "RE_PRINT")
						{
							db.run("create table if not exists re_print ("
									+ " uuid text not null,"
									+ " user_id integer,"
									+ " terminal_id integer,"
									+ " order_id text not null,"
									+ " date_printed text" 
									+ " )");
						}
						else if(table == "PRODUCT_UPDATED")
						{
							db.run("create table if not exists product_updated ("
									+ " m_product_id int,"
									+ " name text,"
									+ " description text,"
									+ " upc text,"
									+ " sku text,"
									+ " old_price real default 0,"
									+ " new_price real default 0,"
									+ " date_updated text"
									+ ")");
						}
						else if(table == "CART_LOG")
						{
							db.run("create table if not exists cart_log ("
									+ " uuid text not null,"
									+ " user_id integer,"
									+ " terminal_id integer,"
									+ " date_logged text,"
									+ " action text not null,"
									+ " qty real default 0,"
									+ " amount real default 0,"
									+ " description text"
									+ " )");
						}
						else if(table == "CASHIER_CONTROL")
						{
							db.run("create table if not exists cashier_control ("
									+ " uuid text not null,"
									+ " user_id integer,"
									+ " terminal_id integer,"
									+ " date_logged text,"
									+ " beginningbalance real default 0,"
									+ " cashamountentered real default 0,"
									+ " cashamount real default 0,"
									+ " externalamountentered real default 0,"
									+ " externalamount real default 0,"
									+ " synchronized text default 'N'"
									+ " )");
						}
						else if(table == "PRODUCT_PRICE" || table == "PRODUCT_PRICE_2")
						{
							db.run("create table if not exists " + table + " ("
									+ " m_product_id int,"
									+ " m_pricelist_id int,"
									+ " pricelist real default 0,"
									+ " pricestd real default 0,"
									+ " pricelimit real default 0,"
									+ " m_attributesetinstance_id int"
									+ ")");
						}
						else if(table == "ATTRIBUTESET_INSTANCE")
						{
							db.run("create table attributeset_instance ("
							+ " m_attributesetinstance_id int,"
							+ " m_attributeset_id int,"
							+ " description text,"
							+ " lot text,"	
							+ " expirydate text"													
							+ ")");
						}
						else if(table == "ORDER_LOG")
						{
							db.run(`create table if not exists order_log (
								id text,
								value text,
								terminal_id integer,
								store_id integer,
								user_id integer,
								documentno text,
								action text,
								date_logged text 
							)`);
						}
						else
						{
							db.run("create table if not exists " + table + " (id text not null, value text)");
						}			
						
					
					}//for

					resolve('created');
				});	
				
				/*
				//check for missing columns
				db.all("SELECT name FROM PRAGMA_TABLE_INFO('search_product') where upper(name) = 'PRICESTD'", function(err, rows) {
		
					if(rows.length == 0){	
						db.run("alter table search_product add column pricestd real default 0");	
					}
				});

				db.all("SELECT name FROM PRAGMA_TABLE_INFO('close_till') where upper(name) = 'DEPOSIT'", function(err, rows) {
		
					if(rows.length == 0){	
						db.run("alter table close_till add column deposit real default 0");
					}
				});
				*/
				
	
			});	//serialize

		});

		return 	promise;

	},
	
	isKeyValue : function(table){

		let tables = [
			"CLOCK_IN_OUT",
			"CLOSE_TILL",
			"OPEN_DRAWER",
			"RE_PRINT",
			"PRODUCT_UPDATED",
			"SYNC_DATE",
			"CART_LOG",
			"CASHIER_CONTROL",
			"PRODUCT_PRICE",
			"PRODUCT_PRICE_2",
			"SEARCH_PRODUCT",
			"ATTRIBUTESET_INSTANCE"
		];

		return tables.indexOf(table.toUpperCase()) < 0;
	},

	getSqlValue : function(sql, params){

		console.log(sql);

		var db = this.getDatabase();

		const promise = new Promise(function(resolve, reject) {

			db.get(sql, params, function(err, row) {
			
				if(err){
					reject(err);
				}
				else
				{
					resolve(row);
				}
			});

		});

		return promise;
	},

	getSqlValues : function(sql, params){

		console.log(sql);

		var db = this.getDatabase();

		const promise = new Promise(function(resolve, reject) {

			db.all(sql, params, function(err, rows) {
			
				if(err){
					reject(err);
				}
				else
				{
					resolve(rows);
				}
			});

		});

		return promise;
	},

	/** insert data functions **/

	put : function(table, json, keyPath){

		let id = json[keyPath] + "";

		let ref = this;

		const promise = new Promise(function(resolve, reject){

			//check if record present
			ref.get(table, id).then(function(row){

				let db = ref.getDatabase();
				
				let value = JSON.stringify(json);
				value = value.replace(/\'/g,"''");

				if(row)
				{
					//update
					db.run("update " + table + " set value = ? where id = ?", [value, id], function(err){

						if(err){							
							console.log(`Failed to update data [${table}] ${keyPath}[${id}]. ${err}`);
							reject(err);
						}
						else
						{
							console.log(`Updated [${table}] ${keyPath}[${id}]`);
							resolve('updated');
						}
						
					});					

				}
				else
				{
					//insert
					db.run("insert into " + table + "(ID, VALUE) values (?, ?)", [id, value], function(err){

						if(err){
							console.log(`Failed to insert data [${table}] ${keyPath}[${id}]. ${err}`);
							reject(err);
						}
						else
						{
							console.log(`Inserted [${table}] ${keyPath}[${id}]`);
							resolve('inserted');
						}						
						
					});				

				}

				

			}).catch(function(error){
				reject(error);
			});

		});

		return promise;

	},

	putAll : function(table, records, keyPath){

		table = table.toUpperCase();
		
		var tables = [
			"USERS",
			"ROLE",
			"ROLE_ORG_ACCESS",
			"BOM",
			"BP",
			"TAX",
			"MODIFIER_GROUP",
			"PRODUCT_MODIFIER_GROUP",
			"PRODUCT",
			"STORE",
			"WAREHOUSE"
		];

		var db = this.getDatabase();
		let ref = this;

		const promise = new Promise(function(resolve, reject){

			var _insertData = function(){

				db.serialize(function(){

					db.run(`DELETE FROM ${table}`, function(err){
						console.log(`Clean table [${table}]`);
					});

					let sql = "BEGIN TRANSACTION;";
  
					var x = 0;
					var record, value;
				
					for (var i = 0; i < records.length; i++) {
						record = records[i];
						id = record['id'] + "";
						value = JSON.stringify(record);
						value = value.replace(/\'/g,"''");

						sql += `INSERT INTO ${table}(ID, VALUE) VALUES ('${id}', '${value}');`;
						x++;
					}
				
				
					sql += "COMMIT;";
					db.exec(sql, function(err) {

						if(err){
							reject(err);
							console.log(err);
						}
						else{
							var msg = `Inserted ${records.length} records into table [${table}]`;
							resolve(msg);
							console.log(msg);
						}
						
					});	
			
				});
			};
	
			if(table == "TERMINAL"){
	
				//check if first time
				ref.getAll("TERMINAL").then(
	
					function(results){
						
						if(results.length == 0){
							_insertData();
						}
						else{
							resolve(`Inserted 0 records into table [${table}]`);
						}
					}
				).catch(function(err){

					reject(err);
	
				});
	
			}//if
			else
			{
				if( tables.indexOf(table) >= 0 ){
					_insertData();
				}
			}

		});	

		return promise;

		
	},

	executeUpdate : function(sql, params){

		console.log(sql, params);

		var db = this.getDatabase();

		const promise = new Promise(function(resolve, reject) {

			let action = sql.trim().split(" ")[0] + "";
			if(action.toLowerCase().endsWith("e")){
				action = action + "d";
			}
			else
			{
				action = action + "ed";
			}

			db.run(sql, params, function(err) {
			
				if(err){
					reject(err);
				}
				else
				{
					resolve(action.toUpperCase());
				}
			});

		});

		return promise;
	},

	purgeSyncData : async function(from){

		let date = from || (moment().subtract(1, 'M').format("YYYY-MM-DD") + " 00:00:00");

		console.log("Purging data from " + date);

		const promise = new Promise((resolve, reject) => {

			let db = this.getDatabase();

			db.serialize( async function(){

				await db.runAsync(" DELETE FROM ORDERS WHERE STATUS = 'CO' AND DATE_ORDERED < ? ", [ date ]);

				await db.runAsync(" DELETE FROM CLOSE_TILL WHERE SYNCHRONIZED = 'Y' AND TIME_CLOSE < ? ", [ date ]);
			
				await db.runAsync(" DELETE FROM CLOCK_IN_OUT WHERE SYNCHRONIZED = 'Y' AND TIME_OUT < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM OPEN_DRAWER WHERE DATE_OPENED < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM RE_PRINT WHERE DATE_PRINTED < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM PRODUCT_UPDATED WHERE DATE_UPDATED  < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM CART_LOG WHERE DATE_LOGGED < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM CASHIER_CONTROL WHERE DATE_LOGGED < ? ", [ date ]);
				
				await db.runAsync(" DELETE FROM ORDER_LOG WHERE DATE_LOGGED < ? ", [ date ]);

				console.log("Purging completed");

				resolve();

			});	
			
			
		});

		return promise;	

	},
	
	runBatch : async function( statements ){
	
		let db = this.getDatabase();
	
		return db.runBatchAsync(statements);
	
	}
};

module.exports = database