let report = require("../posterita/reports/DailyItemSalesReport");

report.default.getReport();