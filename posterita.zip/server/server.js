const { app } = require('electron');
var express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const ENV = require(path.join(app.getAppPath(), "env.json"));

var xpr = express();
xpr.use(bodyParser.urlencoded({ extended: true }));

//authorization
let auth = express.Router();
auth.get("/admin/*", (req, res, next) => {
	console.log("Validating user ..");	
	let authorization = req.headers["authorization"];
	
	if(!authorization){
		res.append('WWW-Authenticate', 'Basic');
		res.status(401).end();
		return;
	}
	else
	{
		//Basic U3VwZXJVc2VyOnAwNXQzcjF0NA==
		if("Basic U3VwZXJVc2VyOnAwNXQzcjF0NA==" != authorization){
			res.status(401).end();
			return;
		}
	}
	
    next();
});
xpr.use('/', auth);

let WEB_DIR = path.join(app.getAppPath(), "web");
xpr.use('/', express.static(WEB_DIR));

//define routes
xpr.get('/json/:table', require('../controllers/json-controller').all);
xpr.get('/json/:table/:id', require('../controllers/json-controller').id);
xpr.post('/json/:table', require('../controllers/json-controller').post);

xpr.get('/till/', require('../controllers/till-controller').till);
xpr.get('/clockinout/', require('../controllers/clock-in-out-controller').clockInOut);
//xpr.get('/service/:service/:action', require('../controllers/online-service-controller').service);
//xpr.post('/service/:service/:action', require('../controllers/online-service-controller').service);
xpr.get('/service/*', require('../controllers/online-service-controller').service);
xpr.post('/service/*', require('../controllers/online-service-controller').service);
xpr.get('/synchronize/', require('../controllers/synchronize-controller').synchronize);
xpr.get('/printing/', require('../controllers/printing-controller').printing);
xpr.post('/printing/', require('../controllers/printing-controller').printing);

xpr.get('/orderHistory/', require('../controllers/order-controller').history);
xpr.get('/report/', require('../controllers/report-controller').report);

xpr.get('/sql/', require('../controllers/sql-controller'));
xpr.get('/system/', require('../controllers/system-controller'));
xpr.post('/system/', require('../controllers/system-controller'));

xpr.get('/log/', require('../controllers/log-controller'));

let httpServer = require('http').createServer(xpr);

let HttpServer = {
    start : function(){

        return new Promise(function(resolve, reject){
            
            httpServer.listen(ENV.PORT, function () {

                try
                {
                    console.log("Server listening on port :%s", ENV.PORT);
                    resolve("Server started");
                }
                catch(e){
                    reject("Failed to start server!");
                }
            })

        });       

    },

    stop : async function(){

        return new Promise(function(resolve, reject){            
            httpServer.close(function(err){
                if(err){
                    reject("Failed to start server! " + err);
                }
                else
                {
                    resolve("Server stopped");
                }
            });
           httpServer = null;
           resolve("Server stopped");
           
        });
        
    }
};

module.exports = HttpServer;