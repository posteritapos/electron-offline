const Database = require('../database/database');
const crypto = require('crypto');

var CartLog = {
    getAll : async function(date_from, date_to, terminal_id){

        let sql = "select uuid, date_logged, user_id, action, qty, amount, description from cart_log where date_logged between ? and ? and terminal_id = ? order by date_logged";

        return Database.getSqlValues(sql, [ date_from, date_to, terminal_id ]);
    },

    log : async function( date_logged, user_id, terminal_id, action, qty, amount, description  ){

        let sql = "insert into cart_log( uuid, date_logged, user_id, terminal_id, action, qty, amount, description ) values ( ?, ?, ?, ?, ?, ?, ?, ? )";

        
        var uuid = crypto.randomUUID();

        await Database.executeUpdate(sql, [
            uuid,
			date_logged,
			user_id,
			terminal_id,
			action,
			qty,
			amount,
			description
        ]);

        return {
            "uuid" : uuid,
			"date_logged" : date_logged,
			"user_id" : user_id,
			"terminal_id" : terminal_id,
			"action" : action,
			"qty" : qty,
			"amount" : amount,
			"description" : description
        };
    }
};

module.exports = CartLog;