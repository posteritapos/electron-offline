const { app } = require('electron')
const axios = require("axios");
const path = require('path');
const config = require(path.join(app.getAppPath(), "config.json"));

module.exports.execute = function (uri, json) {

    let serverURL = config["server-address"];

    var x = {};

    x.merchantKey = config["merchant-key"];
    x.terminalKey = config["terminal-key"];

    let cloned = Object.assign(x, json);

    var form = { "json": JSON.stringify(cloned) };

    const promise = new Promise(async function (resolve, reject) {
    	
    	let isServerReachable = await require("../util/NetworkUtils").isServerReachable();
    	
    	if(!isServerReachable){
    		resolve({"error":"Posterita online server is unreachable. You may try your operation when the server comes online again."});
    		return;
    	}
    	
    	axios({
		  method: 'post',
		  url: serverURL + uri,
		  data: form,
		  headers : {"content-type": "application/x-www-form-urlencoded"}
		}).then(response => {			
			resolve(response.data);			
		}).catch(error => {
			reject({"error":error.message});
		});        

    });

    return promise;

};