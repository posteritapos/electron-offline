const Database = require('../database/database');
const crypto = require('crypto');

var ClockInOut = {

    clockIn : function(terminalId, userId, timeIn){   
        
        const promise = new Promise(function(resolve, reject) {

            const db = Database.getDatabase();

            let sql = "select user_id, terminal_id, uuid, time_in, time_out from clock_in_out where time_out is null and user_id = ? and terminal_id = ? order by time_in desc";

            db.get(sql, [userId, terminalId], async function(err, row) {
                
                if(err){
                    reject(err);
                }
                else
                {
                    if(!row){         

                        //clock user in
                        var uuid = crypto.randomUUID();

                        db.run("insert into clock_in_out(user_id, terminal_id, time_in, uuid) values ( ?, ?, ?, ?)", [
                            userId,
                            terminalId,
                            timeIn,
                            uuid
                        ], function(err){

                            if(err){
                                reject(err);
                            }
                            else
                            {                                
                                resolve({
                                    "uuid" : uuid,
                                    "terminal_id" : terminalId,
                                    "user_id" : userId,
                                    "time_in" : timeIn,
                                    "time_out" : null
                                });
                            }						
                            
                        });                  
                        
                    }//if
                    else
                    {
                        resolve(row);
                    }

                    
                    
                    
                }
            }); 

        });  
        
        return promise;
        
    },

    clockOut : function(terminalId, userId, timeOut){   
        
        const promise = new Promise(function(resolve, reject) {

            const db = Database.getDatabase();

            let sql = " update clock_in_out set time_out = ? where time_out is null and user_id = ? and terminal_id = ? ";

            db.run(sql, [timeOut, userId, terminalId], function(err){
                if(err){
                    reject(err);
                }
                else
                {
                    resolve();
                }
            });

        });  
        
        return promise;
        
    },

    getClockedInUsers : async function(terminalId){

        const promise = new Promise(function(resolve, reject) {

            const db = Database.getDatabase();

            let sql = "select user_id, terminal_id, uuid, time_in, time_out from clock_in_out where time_out is null and terminal_id = ? order by time_in desc";

            db.all(sql, [terminalId], function(err, rows) {
                
                if(err){
                    reject(err);
                }
                else
                {
                    resolve(rows);
                }
            });

        });

        return promise;
    },

    clockOutAll : function(terminalId, timeOut){

        const promise = new Promise(function(resolve, reject) {

            const db = Database.getDatabase();

            let sql = " update clock_in_out set time_out = ?, synchronized = 'N' where time_out is null and terminal_id = ? ";

            db.run(sql, [timeOut, terminalId], function(err){
                if(err){
                    reject(err);
                }
                else
                {
                    resolve();
                }
            });

        });  
        
        return promise;

    },



};

module.exports = ClockInOut;