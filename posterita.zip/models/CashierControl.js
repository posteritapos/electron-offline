const Database = require('../database/database');
const crypto = require('crypto');

var CashierControl = {

    save : async function(date_logged, user_id, terminal_id, cash_amount_entered, externalcard_amount_entered, cash_amount_actual, externalcard_amount_actual){

        const db = Database.getDatabase();

        let sql = "select time_open, opening_amt from close_till where terminal_id = ? and time_close is null order by time_open desc";

        let till =  await Database.getSqlValue(sql, [terminal_id]);

        if( !till ){
            throw Error("Till is already close!");
        }

        let time_open = till["time_open"];
        let opening_amt = till["opening_amt"];           
                    
        
        var uuid = crypto.randomUUID();
        sql = "insert into cashier_control( uuid, user_id, terminal_id, date_logged, beginningbalance, cashamount, cashamountentered, externalamount, externalamountentered ) values ( ?, ?, ?, ?, ?, ?, ?, ?, ? )";

        await Database.executeUpdate(sql,[
            uuid,
            user_id, 
            terminal_id,
            date_logged,
            opening_amt,
            cash_amount_actual,
            cash_amount_entered,
            externalcard_amount_actual,
            externalcard_amount_entered
        ]);
        
        let result = {
            "uuid" : uuid,
            "date_logged" : date_logged,
            "user_id" : user_id,
            "terminal_id" : terminal_id,
            "opening_amt" : opening_amt,
            "cash_amount_entered" : cash_amount_entered,
            "cash_amount" : cash_amount_actual,
            "externalcard_amount_entered" : externalcard_amount_entered,
            "externalcard_amount" : externalcard_amount_actual
        };

        return result;
    },

    getAll : async function(date_from, date_to, terminal_id){

        let sql = "select uuid, date_logged, user_id, beginningbalance, cashamount, cashamountentered, externalamount, externalamountentered from cashier_control where terminal_id = ? and date_logged between ? and ? and synchronized = 'N' order by date_logged";

        return Database.getSqlValues(sql, [terminal_id, date_from, date_to]);
    }

};

module.exports = CashierControl;