const Database = require('../database/database');
const crypto = require('crypto');

var RePrint = {
    getAll : async function( date_from, date_to, terminal_id ){

        let sql = " select uuid, date_printed, user_id, order_id from re_print where terminal_id = ? and date_printed between ? and ? order by date_printed ";

        return Database.getSqlValues(sql, [ terminal_id, date_from, date_to ]);

    },

    print : async function( date_printed, user_id, terminal_id, order_id ){

        let sql = "insert into re_print( uuid, date_printed, user_id, terminal_id, order_id ) values ( ?, ?, ?, ?, ? )";

        var uuid = crypto.randomUUID();

        await Database.executeUpdate(sql, [
            uuid, date_printed, user_id, terminal_id, order_id
        ]);

        return {
            "uuid" : uuid,
			"date_printed" : date_printed,
			"user_id" : user_id,
			"terminal_id" : terminal_id,
			"order_id" : order_id
        };

    }
};

module.exports = RePrint;