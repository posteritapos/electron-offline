const Database = require('../database/database');
const crypto = require('crypto');

var OpenDrawer = {
    getAll : async function(last_time_close_till, time, terminalId){

        let sql = "select uuid,  date_opened, user_id, reason from open_drawer where terminal_id = ? and date_opened between ? and ? order by date_opened ";

        return Database.getSqlValues(sql, [ last_time_close_till, time, terminalId ]);
    },

    open : async function( date_opened, user_id, terminal_id, reason ){

        let sql = "insert into open_drawer( uuid, date_opened, user_id, terminal_id, reason ) values ( ?, ?, ?, ?, ? )";
        
        var uuid = crypto.randomUUID();

        await Database.executeUpdate(sql, [
            uuid, date_opened, user_id, terminal_id, reason
        ]);

        return {
            "uuid" : uuid,
			"date_opened" : date_opened,
			"user_id" : user_id,
			"terminal_id" : terminal_id,
			"reason" : reason
        };
    }


};

module.exports = OpenDrawer;