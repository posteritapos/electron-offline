const { app } = require('electron');
const path = require('path');
const config = require(path.join(app.getAppPath(), "config.json"));
const version = require(path.join(app.getAppPath(), "version.json"));
const Database = require('../database/database');

const Application = {

    sendErrorLog : function(){
        return false;
    },

    getSystemInfo : async function(){

        let info = {};

        info["server-address"] = config["server-address"];
		info["domain"] =  config["domain"];
		info["merchant-key"] = config["merchant-key"];
        info["terminal-key"] = config["terminal-key"];        
        
        let result = await Database.getSqlValue("select sequence_no sequence_no from terminal where id = ? ",[ config["terminal-key"] ]);
        info["documentno_sequence"] = result['sequence_no'];

        let systemSyncDate = await this.getSynchronizationDate("SYSTEM");
        let ordersSyncDate = await this.getSynchronizationDate("ORDERS");

        info["system-sync-date"] =systemSyncDate;
        info["orders-sync-date"] = ordersSyncDate;
        
        //todo
        info["version"] = "2.0";
		info["built"] = version["version"];

        return info;
    },

    getSynchronizationDate : async function(event){
        
        let result = await Database.getSqlValue("select eventdate eventdate from SYNC_DATE where upper(EVENT) = ? ", [ event.toUpperCase() ]);

        return result == undefined ? "-" : result["eventdate"];
    },

    /* deprecated */
    startServerMonitoring : function(){},

    stopServerMonitoring : function(){},

    isServerUp : function(){
        return true;
    },

    getServerStatus : function(){
        return {"up" : false};
    }

};

module.exports = Application;