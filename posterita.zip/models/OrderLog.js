const Database = require('../database/database');
const crypto = require('crypto');

const OrderLog = {
    log : async function(id, json, documentno, action, date_logged, store_id, user_id, terminal_id){

        let sql = "insert into order_log( id, value, documentno, action, date_logged, store_id, user_id, terminal_id ) values ( ?, ?, ?, ?, ?, ?, ?, ? )";

        var uuid = crypto.randomUUID();

        await Database.executeUpdate(sql, [
            uuid,
			json, 
            documentno, 
            action, 
            date_logged, 
            store_id, 
            user_id, 
            terminal_id
        ]);

    }
};

module.exports = OrderLog;