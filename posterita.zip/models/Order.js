const Database = require('../database/database');
const OnlineServiceExecutor = require('./OnlineServiceExecutor');
const crypto = require('crypto');

var Order = {

    _save : async function( order ){

        let uuid, store_id, customer_id, user_id, terminal_id;		
        let doc_status, order_type, tender_type, document_no, status;

        if(order["uuid"]){
            uuid = order["uuid"];
        }
        else
        {
            uuid = order["orderId"];
        }

        status = order["status"];
        
        document_no = order["documentNo"];
        tender_type = order["tenderType"];
        order_type = order["orderType"];
        doc_status = order["docAction"];
        
        store_id = order["orgId"];
        customer_id = order["bpartnerId"];
        user_id = order["salesRepId"];
        terminal_id = order["terminalId"];

        let json = JSON.stringify(order);
        let dateOrdered = order["dateOrdered"];
        
        await Database.executeUpdate("delete from ORDERS where ID = ?", [uuid]);

        let insertStmt = "INSERT INTO ORDERS (ID, VALUE, STATUS, TERMINAL_ID, DATE_ORDERED, STORE_ID, CUSTOMER_ID, USER_ID, DOCUMENTNO, DOCSTATUS, TENDERTYPE, ORDERTYPE) "
        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
        
        let params = [

            uuid,
            json,
            status,
            terminal_id,
            dateOrdered,                    
            store_id,
            customer_id,
            user_id,   							
            document_no,
            doc_status,
            tender_type,
            order_type
        ]; 
        
        await Database.executeUpdate(insertStmt, params);

        return order; 

    },

    save : async function(order){  
        
        
        let uuid = null;
        
        // do not assign document no to online orders
        if(order["isOnline"]){
            return order;
        }
        
        if(order["uuid"]){
            uuid = order["uuid"];
        }
        else
        {
            uuid = order["orderId"];
        }
        
        let terminalId = order["terminalId"];
        let docAction = order["docAction"];
        
        // add columns to help query
        let dateOrdered = order["timestamp"];
        
        //fix date bug
        if(order["backdate"]){
            //do nothing
        }
        else if(order["timestamp"])
        {
            /*
            //validate dateOrdered
            //difference between 2 dates due to javafx javascript date bug
            Date t = new Date(order.getLong("timestamp"));
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            
            String x = sdf.format(t);
            
            if( !x == (order["dateOrdered"))){
                
                //correct dateordered
                order.put("dateOrdered", x);
                order.put("dateCorrected", true);
                
                json = order.toString();
            }
            */           
            
        }
        
        /* flag for online synchronized order */
        let synchronizeDraftOrder = false;
        
        if( order["synchronizeDraftOrder"] ){
            if( order["synchronizeDraftOrder"] == true ){
                synchronizeDraftOrder = true;
            }
        }
        
        if( synchronizeDraftOrder ){            
            
            return this._save(order);            
        }
        
        /* flag for online processing */				
        let processOnline = false;
        
        let tenderType = order["tenderType"];
        
        if("Card" == tenderType 
                || "Credit" == tenderType
                || "Voucher" == tenderType
                || "Loyalty" == tenderType
                || "Gift Card" == tenderType)
        {
            processOnline = true;
        }

        if( !processOnline )
        {
            // loop through lines
            
            let lines = order["lines"];
            let productName;
            
            for( let line of lines )
            {
                 productName = line["productName"];
                
                // check for coupon
                if( "Coupon" == ( productName )  
                        || "Issue Gift Card" == ( productName )
                        || "Redeem Gift Card" == ( productName )
                        || "Reload Gift Card" == ( productName )
                        || "Refund Gift Card" == ( productName ) 
                        || "Issue Deposit" == ( productName )
                        || "Redeem Deposit" == ( productName )
                        || "Refund Deposit" == ( productName )
                        || "Redeem Promotion" == ( productName )){
                        
                    processOnline = true;
                    break;
                }
            }    					
            
        }

        let previousOrderJSON = await Database.get("ORDERS", uuid);
        
        if(previousOrderJSON == null)
        {                       
            try 
            {

                let terminal = await Database.getSqlValue(" select sequence_prefix, sequence_no from terminal where id = ? ",[ terminalId ]);
                if(!terminal){
                    throw new Error("Data error. Failed to load terminal!");
                }
            
                let sequence_prefix = terminal["sequence_prefix"];
                let sequence_no = terminal["sequence_no"];
                let new_sequence_no = sequence_no + 1;
                
                let mask = "00000000" + new_sequence_no;
                let documentNo = mask.substring(mask.length - 8);
                
                if(sequence_prefix != null)
                {
                    documentNo = sequence_prefix + documentNo;
                }									
                
                order["documentNo"] = documentNo;
                order["offlineDocumentNo"] = documentNo;
                
                //json = order.toString();
                
                // process online based on tenderType						
                if(processOnline)
                {    
                    try 
                    {                        
                        let executor = new OnlineServiceExecutor()

                        let response = await executor.excecute("/service/v2/Order/checkout", order);

                        //validate returned json
                        if(response["error"])
                        {
                            return response;
                        }

                        order = response;
                    
                    } 
                    catch (e) 
                    {
                        throw new Error("Server error. " + e);
                    }
                    
                }
                
                order = await this._save( order );
                
                //update sequence number at the end
                try
                {
                    await Database.executeUpdate("update terminal set sequence_no = ? where id = ?", [ new_sequence_no, terminalId ]);
                }
                catch(e){

                    throw new Error("Failed to update document sequence!");
                }
                
                return order;
                
            } 
            catch (e) 
            {
                throw e;
            }            									
            
        }
        else
        {
            // check for drafted order
            let previousOrder = previousOrderJSON;
            let previousDocAction = previousOrder["docAction"];
            
            let documentNo = previousOrder["offlineDocumentNo"];
            let orderId = previousOrder["orderId"];
            
            if( documentNo != null )
            {
                order["documentNo"] = documentNo;
                order["offlineDocumentNo"] = documentNo;
            }
            
            if( orderId != null && !orderId == ("0")) 
            {
                order["orderId"] = orderId;
            }
            
            //json = order.toString();
            
            if("DR" == (previousDocAction) && ("DR" == (docAction) || "CO" == (docAction))) {						
                if("Card" == (tenderType) 
                        || "Credit" == (tenderType)
                        || "Voucher" == (tenderType)
                        || "Loyalty" == (tenderType)
                        || "Gift Card" == (tenderType))
                {
                    processOnline = true;
                } 
                
                await Database.executeUpdate("update ORDERS set DATE_ORDERED = ? where ID = ?", [dateOrdered, uuid]);
                
                if(!processOnline)
                {
                    //reset status -- see DatabaseSynchronizer line 355
                    await Database.executeUpdate("update ORDERS set STATUS = 'RP' where ID = ?", [uuid]);
                    order["status"] = "RP";
                    //json = order.toString();

                    return this._save(order);
                }               
                else
                {
                    try 
                    {
                        let executor = new OnlineServiceExecutor()

                        let response = await executor.excecute("/service/v2/Order/checkout", order);

                        //validate returned json
                        if(response["error"])
                        {
                            return response;
                        }

                        order = response;

                        return this._save(order);
                    } 
                    catch (e) 
                    {
                        throw new Error("Server error. " + e);
                    }     
                   
                    
                }
            }
        }
    }
};

module.exports = Order;