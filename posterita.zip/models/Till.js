const Database = require('../database/database');
const crypto = require('crypto');
const BigNumber = require("./BigNumber");

const OpenDrawer = require("../models/OpenDrawer");
const RePrint = require("../models/RePrint");
const CartLog = require("../models/CartLog");
const CashierControl = require("../models/CashierControl");

var Till = {
    isOpen: async function (terminalId) {

        let sql = "select uuid from close_till where terminal_id = ? and time_close is null order by time_open desc";

        let uuid = await Database.getSqlValue(sql, [terminalId]);

        if (uuid) {
            return true;
        }

        return false;
    },

    isClose: async function (terminalId) {

        if (await this.isOpen(terminalId)) {
            //still open
            return false;
        }

        return true;

    },

    open: async function (terminal_id, open_user_id, time_open, opening_amt) {

        let isClose = await this.isClose(terminal_id);

        if (!isClose) return;

        var uuid = crypto.randomUUID();

        let sql = "insert into close_till(uuid, terminal_id, open_user_id, time_open, opening_amt) values (?, ?, ?, ?, ?) ";
        let params = [
            uuid,
            terminal_id,
            open_user_id,
            time_open,
            opening_amt
        ];

        await Database.executeUpdate(sql, params);

        let json = {
            "uuid": uuid,
            "terminal_id": terminal_id,
            "open_user_id": open_user_id,
            "time_open": time_open,
            "opening_amt": opening_amt
        };

        return json;

    },

    close: async function (terminalId, userId, closingAmt, extCardAmount, time, syncDraftAndOpenOrders) {

        let till = await Database.getSqlValue("select uuid, open_user_id, time_open, opening_amt from close_till where terminal_id = ? and time_close is null order by time_open desc", [terminalId]);

        if (!till) {
            throw new Error("Till is already close!");
        }

        let uuid = till["uuid"];
        let open_user_id = till["open_user_id"];
        let time_open = till["time_open"];
        let opening_amt = till["opening_amt"];

        // get current money in terminal			
        let payments = await this.getCurrentMoneyInTill(terminalId, time_open);
        let timeClose = await this.getLastTimeCloseTill(terminalId);

        let last_time_close_till = null;

        if (timeClose != undefined && timeClose["time_close"]) {
            last_time_close_till = timeClose["time_close"];
        }
        else {
            last_time_close_till = time_open;
        }

        // get logs
        let openDrawerLogs = await OpenDrawer.getAll(last_time_close_till, time, terminalId);/*time_open*/
        let rePrintLogs = await RePrint.getAll(time_open, time, terminalId);
        let cartLogs = await CartLog.getAll(time_open, time, terminalId);
        let cashierControls = await CashierControl.getAll(time_open, time, terminalId);

        let cash = payments["cash"];
        let card = payments["card"];
        let cheque = payments["cheque"];
        let gift = payments["gift"];
        let voucher = payments["voucher"];
        let ext_card = payments["ext_card"];
        let loyalty = payments["loyalty"];
        let coupon = payments["coupon"];
        let deposit = payments["deposit"];

        /* mobile payments */
        let mcb_juice = payments["mcbJuice"];
        let myt_money = payments["mytMoney"];
        let emtel_money = payments["emtelMoney"];
        let gifts_mu = payments["giftsMu"];

        //validate closing amount == cash + opening amount

        let json = payments;

        json["uuid"] = uuid;
        json["terminal_id"] = terminalId;
        json["open_user_id"] = open_user_id;
        json["time_open"] = time_open;
        json["opening_amt"] = opening_amt;

        json["close_user_id"] = userId;
        json["time_close"] = time;
        json["closing_amt"] = closingAmt;

        json["openDrawers"] = openDrawerLogs;
        json["rePrints"] = rePrintLogs;
        json["cartLogs"] = cartLogs;
        json["cashierControls"] = cashierControls;
        json["ext_card_amount_entered"] = extCardAmount;

        /* mark draft and open orders */
        if(syncDraftAndOpenOrders){

            let draftOrders = json["draftOrders"];
		    let openOrders = json["openOrders"];

            let ids = draftOrders.concat(openOrders);

            if(ids.length > 0){               

                let uuids = "'" + ids.join("','") + "'";

                let results = await Database.getSqlValues(" select value value from orders where id in (" + uuids + ")", []);
                let order;

                let db = Database.getDatabase();
                let stmt = db.prepare("update orders set value = ? where id = ?");

                for(let i=0; i<results.length; i++){
                    order = JSON.parse(results[i]['value']);
                    order["pushDraftAndOpenOrders"] = true;

                    stmt.run(JSON.stringify(order), order["uuid"]);
                }

                stmt.finalize();
            }

        }
		



        let sql = "update close_till set close_user_id = ?  ,time_close = ?  , closing_amt = ?  , cash = ?  , "
            + "card = ?  , cheque = ?  , gift = ?  , voucher = ?  , ext_card = ?  , loyalty = ?, coupon = ?, deposit = ?, "
            + " mcbJuice = ?, mytMoney = ?, emtelMoney = ?, giftsMu = ?, "
            + "json = ?  where uuid = ?";

        let params = [

            userId,
            time,
            closingAmt,

            cash,
            card,
            cheque,
            gift,
            voucher,
            ext_card,
            loyalty,
            coupon,
            deposit,

            /* mobile payments */
            mcb_juice,
            myt_money,
            emtel_money,
            gifts_mu,

            JSON.stringify(json), // save a copy of receipt in json format		
            uuid
        ];

        await Database.executeUpdate(sql, params);

        return json;

    },

    getTenderAmounts: async function (terminal_id) {

        let sql = "select time_open, opening_amt from close_till where terminal_id = ? and time_close is null order by time_open desc";

        let till = await Database.getSqlValue(sql, terminal_id);

        let time_open = null;

        if (till) {

            time_open = till["time_open"];
        }

        return this.getCurrentMoneyInTill(terminal_id, time_open);
    },

    getCurrentMoneyInTill: async function (terminal_id, time_open) {

        let cash = new BigNumber(0);
        let card = new BigNumber(0);
        let cheque = new BigNumber(0);
        let gift = new BigNumber(0);
        let voucher = new BigNumber(0);
        let ext_card = new BigNumber(0);
        let loyalty = new BigNumber(0);
        let coupon = new BigNumber(0);
        let deposit = new BigNumber(0);

        /* mobile payments */
        let mcbJuice = new BigNumber(0);
        let mytMoney = new BigNumber(0);
        let emtelMoney = new BigNumber(0);
        let giftsMu = new BigNumber(0);

        let grandTotal = new BigNumber(0);
        let taxTotal = new BigNumber(0);
        let discountTotal = new BigNumber(0);

        let userDiscountTotal = new BigNumber(0);

        let noOfOrders = new BigNumber(0);
        let noOfReturns = new BigNumber(0);

        let qtySold = new BigNumber(0);
        let qtyReturned = new BigNumber(0);

        let qtyServicesSold = new BigNumber(0);
        let qtyServicesReturned = new BigNumber(0);

        let splitSalesReps = null;
        let splitSalesRep = null;

        let salesRepSalesTotal = null;

        let discountCodeMap = {};

        let employeeSalesMap = {};

        let orderTotal = new BigNumber(0);      

        let rows = await Database.getSqlValues(" select value from orders where terminal_id = ? and date_ordered >= ? ", [terminal_id, time_open]);

        console.log(`Looked for orders terminal[${terminal_id}] and time[${time_open}], found ${rows.length} orders.`);

        let order = null;

        for (let row of rows) {

            order = row["value"];
            order = JSON.parse(order);

            if ("CO" != order["docAction"]) {
                continue;
            }

            let negate = -1;

            if ("POS Order" == order["orderType"]) {
                negate = 1;
                noOfOrders = noOfOrders.plus(1);
            }
            else {
                noOfReturns = noOfReturns.plus(1);
            }

            let amt = 0;
            let userDiscount = 0;
            let qty = 0;

            amt = order["taxTotal"] * negate;
            taxTotal = taxTotal.plus(amt);

            amt = order["grandTotal"] * negate;

            orderTotal = amt;
            grandTotal = grandTotal.plus(orderTotal);

            //employee sales
            splitSalesReps = order["splitSalesReps"]; //order.splitSalesReps

            let splitSalesRepName = null;
            let splitSalesAmount = new BigNumber(0);

            for (splitSalesRep of splitSalesReps) {

                splitSalesRepName = splitSalesRep["name"];
                splitSalesAmount = splitSalesRep["amount"];

                if (employeeSalesMap[splitSalesRepName]) {
                    salesRepSalesTotal = employeeSalesMap[splitSalesRepName];

                }
                else {
                    salesRepSalesTotal = new BigNumber(0);
                }

                salesRepSalesTotal = salesRepSalesTotal.plus(splitSalesAmount);
                employeeSalesMap[splitSalesRepName] = salesRepSalesTotal;
            }

            let lines = order["lines"];
            let line = null;

            let discountCodeMapEntry;

            let isService = false;

            let priceEntered = 0;

            for (line of lines) {

                let description = null;

                description = line["description"];
                priceEntered = line["priceEntered"];

                if (description.startsWith("Redeem Gift Card - ")) {

                    gift = gift.plus(priceEntered).negate();
                    continue;
                }
                else if (description.startsWith("Coupon - ")) {

                    coupon = coupon.plus(priceEntered);
                    continue;
                }
                else if (description.startsWith("Issue Gift Card - ") || description.startsWith("Reload Gift Card - ")) {
                    continue;
                }
                else if(description.startsWith("Redeem Deposit - ")) {
						
                    deposit = deposit.plus(priceEntered).negate();
                    continue;
                }

                amt = line["discountAmt"] * negate;
                discountTotal = discountTotal.plus(amt);

                // qty sold & returned
                qty = new BigNumber(line["qtyEntered"]);

                isService = false;

                if (line["producttype"]) {

                    if ("S" == line["producttype"]) {
                        isService = true;
                    }

                }

                let u_pos_discountcode_id = line["u_pos_discountcode_id"];

                if (u_pos_discountcode_id && u_pos_discountcode_id > 0) {
                    let discountAmt = line["discountAmt"];

                    discountCodeMapEntry = discountCodeMap[u_pos_discountcode_id];

                    if (discountCodeMapEntry == null) {
                        discountCodeMapEntry = {};
                        discountCodeMapEntry["qty"] = 1;
                        discountCodeMapEntry["amt"] = discountAmt;
                        discountCodeMapEntry["u_pos_discountcode_id"] = u_pos_discountcode_id;

                    }
                    else {
                        discountCodeMapEntry["qty"] = discountCodeMapEntry["qty"] + 1;
                        discountCodeMapEntry["amt"] = discountCodeMapEntry["amt"] + discountAmt;
                    }

                    discountCodeMap[u_pos_discountcode_id] = discountCodeMapEntry;
                }
                else {
                    if (line["priceStd"]
                        && line["priceStd"] != line["priceEntered"]) {

                        userDiscount = (line["priceList"] - line["priceEntered"]) * qty;
                        userDiscountTotal = userDiscountTotal.plus(userDiscount);
                    }
                }


                if (negate == 1) {
                    if (qty.float() > 0) {
                        qtySold = qtySold.plus(qty);

                        if (isService) {
                            qtyServicesSold = qtyServicesSold.plus(qty);
                        }
                    }
                    else {
                        qtyReturned = qtyReturned.plus(qty.negate());

                        if (isService) {
                            qtyServicesReturned = qtyServicesReturned.plus(qty.negate());
                        }
                    }
                }
                else {
                    if (qty.float() > 0) {
                        qtyReturned = qtyReturned.plus(qty);

                        if (isService) {
                            qtyServicesReturned = qtyServicesReturned.plus(qty);
                        }
                    }
                    else {
                        qtySold = qtySold.plus(qty.negate());

                        if (isService) {
                            qtyServicesSold = qtyServicesSold.plus(qty.negate());
                        }
                    }
                }
            }//for

            let payments = order["payments"];
            let tenderType;

            for (let payment of payments) {

                tenderType = payment["tenderType"];
                amt = payment["payAmt"] * negate;

                if ("Cash" == (tenderType)) {
                    cash = cash.plus(amt);
                }
                else if ("Card" == (tenderType)) {
                    card = card.plus(amt);
                }
                else if ("Cheque" == (tenderType)) {
                    cheque = cheque.plus(amt);
                }
                else if ("Gift Card" == (tenderType)) {
                    gift = gift.plus(amt);
                }
                else if ("Voucher" == (tenderType)) {
                    voucher = voucher.plus(amt);
                }
                else if ("Ext Card" == (tenderType)) {
                    ext_card = ext_card .plus(amt);
                }
                else if ("Loyalty" == (tenderType)) {
                    loyalty = loyalty.plus(amt);
                }

                /* mobile payments */
                else if ("MCB Juice" == (tenderType)) {
                    mcbJuice = mcbJuice.plus(amt);
                }
                else if ("MY.T Money" == (tenderType)) {
                    mytMoney = mytMoney.plus(amt);
                }
                else if ("Emtel Money" == (tenderType)) {
                    emtelMoney = emtelMoney.plus(amt);
                }
                else if("Gifts.mu" == (tenderType))
                {
                    giftsMu = giftsMu.plus(amt);
                }
            }

        }

        let json = {};
        json["cash"] = cash.float();
        json["card"] = card.float();
        json["cheque"] = cheque.float();
        json["ext_card"] = ext_card.float();
        json["voucher"] = voucher.float();
        json["gift"] = gift.float();
        json["loyalty"] = loyalty.float();
        json["coupon"] = coupon.negate().float();
        json["deposit"] = deposit.float();

        /* mobile payments */
        json["mcbJuice"] = mcbJuice.float();
        json["mytMoney"] = mytMoney.float();
        json["emtelMoney"] = emtelMoney.float();
        json["giftsMu"] = giftsMu.float();

        json["taxTotal"] = taxTotal.float();
        json["grandTotal"] = grandTotal.float();
        json["subTotal"] = grandTotal.minus(taxTotal).float();
        json["discountTotal"] = discountTotal.float();
        json["userDiscountTotal"] = userDiscountTotal.float();

        json["noOfOrders"] = noOfOrders.int();
        json["noOfReturns"] = noOfReturns.int();

        json["qtySold"] = qtySold.float();
        json["qtyReturned"] = qtyReturned.float();

        json["qtyItemsSold"] = qtySold.minus(qtyServicesSold).float();
        json["qtyItemsReturned"] = qtyReturned.minus(qtyServicesReturned).float();

        json["qtyServicesSold"] = qtyServicesSold.float();
        json["qtyServicesReturned"] = qtyServicesReturned.float();

        //put discount codes
        let discountCodes = Object.values(discountCodeMap);
        json["discountCodes"] = discountCodes;

        //put employee sales
        let employeeSales = [];

        let names = Object.keys(employeeSalesMap);

        for (let name of names) {

            employeeSales.push({
                "name": name,
                "amt": employeeSalesMap[name].float()
            });
        }

        json["employeeSales"] = employeeSales;

        //draft orders
        let draftOrders = await this.getDraftOrders(terminal_id);
        json["draftOrders"] = draftOrders;
        
        //open orders
        let openOrders = await this.getOpenOrders(terminal_id);
        json["openOrders"] = openOrders;

        return json;

    },

    validateCashAmount: async function (terminal_id, cashAmountEntered) {

        let sql = "select time_open, opening_amt from close_till where terminal_id = ? and time_close is null order by time_open desc";

        let till = await Database.getSqlValue(sql, [terminal_id]);

        let time_open = till["time_open"];
        let opening_amt = till["opening_amt"];

        let payments = await this.getCurrentMoneyInTill(terminal_id, time_open);

        let cash = payments["cash"];

        let expectedCashAmount = cash;
        expectedCashAmount = expectedCashAmount + opening_amt;

        console.log(`Validating till balance. Entered : ${cashAmountEntered}, Expected : ${expectedCashAmount}`);

        if (cashAmountEntered == expectedCashAmount) {
            return true;
        }

        return false;

    },

    getLastTimeCloseTill: async function (terminal_id) {

        let sql = "select uuid, time_close from close_till where time_close=( select max(time_close) from close_till where terminal_id = ? ) and terminal_id = ?";
        let params = [
            terminal_id,
            terminal_id
        ];

        return Database.getSqlValue(sql, params);
    },

    /* draft orders that have not been synchronized */
	getDraftOrders: async function(terminal_id){

        let draftOrders = [];

        let results = await Database.getSqlValues("select value from orders where status in ('', 'DR','IP', 'RP') and docstatus = 'DR' and terminal_id = ?", [terminal_id]);

        if(results.length == 0) return draftOrders;

        let order = null;       

        for(let i=0; i<results.length; i++){

            order = JSON.parse(results[i]["value"]);

            if(order["pushDraftAndOpenOrders"]) continue;

            draftOrders.push(order["uuid"]);
        }

        return draftOrders;

    },

    /* get open orders */
	getOpenOrders: async function(terminal_id){

        let openOrders = [];

        let results = await Database.getSqlValues("select value from orders where status in ('', 'DR','IP', 'RP')  and tendertype = 'Mixed' and terminal_id = ?", [terminal_id]);

        if(results.length == 0) return openOrders;

        let order, openAmt, payments, payment, payAmt;       

        for(let i=0; i<results.length; i++){            

            order = JSON.parse(results[i]["value"]);

            if(order["pushDraftAndOpenOrders"]) continue;

            //check for open amt
			openAmt = new BigNumber(order["grandTotal"]);
            payments = order["payments"];

            for(let j=0; j<payments.length; j++){
                payment = payments[j];
                payAmt = payment["payAmt"];
                openAmt = openAmt.minus(payAmt);
            }

            if(openAmt.float() != 0.0){
                openOrders.push(order["uuid"]);
            }            
        }

        return openOrders;

    

    }

};

module.exports = Till;