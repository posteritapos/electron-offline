const Database = require('../database/database');
const OnlineServiceExecutor = require('./OnlineServiceExecutor');
const OrderLog = require('./OrderLog');
const moment = require("moment");

const Order = {

	save : async function(order)
	{
		// set document no if none
		try 
		{	
			order["posVersion"] = 'ElectronJS';
			//order.put("javaVersion", Application.JAVA_VERSION);
			//order.put("javaVendor", Application.JAVA_VENDOR);

			// saving an online order
			// order may not have uuid
			let orderId = order["orderId"] || 0;
			
			if(orderId > 0) {
				if(!order["uuid"]){
					order["uuid"] = order["orderId"];
				}
			}
			
			let uuid = order["uuid"];			

			let docAction = order["docAction"];			
			let terminalId = order["terminalId"];

            /*
			// add columns to help query
			int terminal_id = Integer.valueOf(terminalId);
			Timestamp dateOrdered = Timestamp.valueOf(order["dateOrdered"]);

			//fix date bug
			if(order.has("backdate")){
				//do nothing
			}
			else if(order.has("timestamp"))
			{
				//validate dateOrdered
				//difference between 2 dates due to javafx javascript date bug
				Date t = new Date(order.getLong("timestamp"));
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

				String x = sdf.format(t);

				if( !x == order["dateOrdered"))){

					//correct dateordered
					order.put("dateOrdered", x);
					order.put("dateCorrected", true);
				}    					
			}
            */

			/* need to assign documentno for new orders */
			let isNewOrder = true;

			let previousOrder = await Database.get("ORDERS", uuid);
			if( previousOrder != null) {
				isNewOrder = false;
				
				//fix missing documentno
				order["documentNo"] = previousOrder["documentNo"];
			}

			/* flag for online processing */				
			let processOnline = false;

			//process online only completed orders			
			if("CO" == docAction) {

				let tenderType = order["tenderType"];

				if("Card" == tenderType 
						|| "Credit" == tenderType
						|| "Voucher" == tenderType
						|| "Loyalty" == tenderType
						|| "Gift Card" == tenderType)
				{
					processOnline = true;
				}

				if( !processOnline )
				{
					// loop through lines

					let lines = order["lines"];
					let line = null;

					for( let i=0; i<lines.length; i++ )
					{
						line = lines[i];

						let productName = line["productName"];

						// check for coupon
						if( "Coupon" ==  productName  

								|| "Issue Gift Card" ==  productName
								|| "Redeem Gift Card" ==  productName
								|| "Reload Gift Card" ==  productName
								|| "Refund Gift Card" ==  productName

								|| "Issue Deposit" ==  productName
								|| "Redeem Deposit" ==  productName
								|| "Refund Deposit" ==  productName

								|| "Redeem Promotion" ==  productName ){

							processOnline = true;
							break;
						}
					}  					

				}
			}


			/* generate document no for new orders and process orders online */

			try 
			{		
                let new_sequence_no = 0;

				if(isNewOrder) {	

                    let terminal = await Database.getSqlValue(" select sequence_prefix, sequence_no from terminal where id = ? ",[ terminalId ]);
                    if(!terminal){
                        throw new Error("Data error. Failed to load terminal!");
                    }
                
                    let sequence_prefix = terminal["sequence_prefix"];
                    let sequence_no = terminal["sequence_no"];
                    new_sequence_no = sequence_no + 1;
                    
                    let mask = "00000000" + new_sequence_no;
                    let documentNo = mask.substring(mask.length - 8);
                    
                    if(sequence_prefix != null)
                    {
                        documentNo = sequence_prefix + documentNo;
                    }	

                    order["documentNo"] = documentNo;
                    order["offlineDocumentNo"] = documentNo;

                    //todo save updated sequence number at the end
										
				}
				
				let order_sync_status = "DR";


				// process online based on tenderType						
				if(orderId == 0 && processOnline)
				{
					console.log("Processing order #" + order["documentNo"] + " online ...");

                    let response = await OnlineServiceExecutor.execute("/service/v2/Order/checkout", order);

                    //validate returned json
                    if(response["error"])
                    {
                        return response;
                    }

                    order = response;
                    order_sync_status = "CO";

                    /*
					//validate returned json
					if(json.trim().startsWith("{"))
					{
						JSONObject j = new JSONObject(json);
						if(j.has("error"))
						{
							order_sync_status = "ER";
							log.error(j["error"));
						}
					}
                    */
				}    
                
                if(isNewOrder){
                    //save terminal document sequence
                    await Database.executeUpdate("update terminal set sequence_no = ? where id = ?", [ new_sequence_no, terminalId ]);
                }                

				let documentno = order["documentNo"];
				let tendertype = order["tenderType"];
				let ordertype = order["orderType"];
				let docstatus = order["docAction"];
                let dateOrdered = order["dateOrdered"];

				let store_id = order["orgId"];
				let customer_id = order["bpartnerId"];
				let user_id = order["salesRepId"];
				
				let orderJSON = JSON.stringify(order);
				
				// save order log
				let logged = OrderLog.log(uuid, orderJSON, documentno, isNewOrder ? "INSERT" : "UPDATE", moment().format('YYYY-MM-DD HH:mm:ss'), store_id, user_id, terminalId);
				if(!logged) {
					throw new OrderException("Failed to save order to order log!");
				}

				if(isNewOrder) {	
					
					console.log("Saving new order #" + documentno);

					let sql = "INSERT INTO ORDERS (ID, VALUE, STATUS, TERMINAL_ID, DATE_ORDERED, STORE_ID, CUSTOMER_ID, USER_ID, DOCUMENTNO, DOCSTATUS, TENDERTYPE, ORDERTYPE) "
							+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";

                    await Database.executeUpdate(sql, [
                        uuid,
                        orderJSON, 
                        order_sync_status, 
                        terminalId, 
                        dateOrdered, 
                        store_id, 
						customer_id,
                        user_id,
                        documentno,
                        docstatus,
                        tendertype,
                        ordertype
                    ]);

				}
				else
				{
					console.log("Updating old order #" + documentno);
					
					let sql = "update ORDERS set STATUS = ?, VALUE = ?, DATE_ORDERED = ?, TERMINAL_ID = ?, STORE_ID = ?, CUSTOMER_ID = ?, USER_ID = ?, DOCSTATUS = ?, TENDERTYPE = ? where ID = ?";
					
                    await Database.executeUpdate(sql, [
                        order_sync_status,
                        orderJSON,
                        dateOrdered,
                        terminalId,
                        store_id,
                        customer_id,
                        user_id,
                        docstatus,
                        tendertype,
                        uuid
                    ]);
				}
				
				return order;

			} 
			catch (e) 
			{
                console.log(e);
            }

		}
		catch (e) 
		{
			console.log(e);
		}
	},

    _saveDocumentNo : async function(new_sequence_no, terminalId){
        //update sequence number at the end
        try
        {
            await Database.executeUpdate("update terminal set sequence_no = ? where id = ?", [ new_sequence_no, terminalId ]);
        }
        catch(e){

            throw new Error("Failed to update document sequence!");
        }
    }
	
}

module.exports = Order;
