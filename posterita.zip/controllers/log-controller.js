const { app } = require('electron')
const path = require('path')
const fs = require('fs')

module.exports = async function (req, res) {

  try {

    //let logFilePath = path.join(app.getPath("logs"), "main.log");
    //res.send(logFilePath).end();

    var options = {
        root: app.getPath("logs")
    };

    let fileName = "main.log";

    res.set('Content-Type', 'text/plain');
    res.sendFile(fileName, options, function (err) {
        if (err) {
            throw err;
        } else {
            console.log('Sent:', fileName);
        }
    });

  } catch (error) {
    res.send(error.message);
  }

};