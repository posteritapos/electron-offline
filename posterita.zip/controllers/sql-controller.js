const Database = require("../database/database");

module.exports = async function (req, res) {

    try {

      let sql = req.query.q;
    	
    	if(sql == null) {
    		
        res.json({ "error": "SQL required!" });
        return;    		
      }
      
      console.log(`Executing: ${sql}`);
      
      if(sql.startsWith("select ")){

        let records = await Database.getSqlValues(sql, []);
        
        let columns = [];
        let data = [];
        
        if(records.length == 0){
        	res.json({ "error": "No records found!" });
        	return;
        }
        
        let record = records[0];
    	let keys = Object.keys(record);        	
    	columns = keys.map( x => {
    		return {
    			"title" : x,
    			"sTitle" : x
    		};
    	});
    	
    	data = records.map( x => {
    		return Object.values(x);
    	});
        
        res.json({
        	"columns" : columns,
        	"data" : data
        });
        return;

      }
      else if(sql.startsWith("update ") 
        || sql.startsWith("create ") 
        || sql.startsWith("delete ") 
        || sql.startsWith("drop ") 
        || sql.startsWith("alter ") 
        || sql.startsWith("insert ")){

        let result = await Database.executeUpdate(sql, []);
        res.json({
        	'columns' : [{
        		"title" : "Records",
        		"sTitle" : "Records"
        	}],
        	"data" : [result]
        });
        return;

      }
      else{
        res.json({ "error": "Invalid SQL" });
      }
    }
    catch(e){

      res.json({ "error": e.message});

    }

  };