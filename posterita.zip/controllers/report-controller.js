const Database = require("../database/database");

exports.report = async function (req, res) {

    let reportName = req.query.name;
    let format = req.query.format;

    let Report = require("../reports/" + reportName);

    let report = new Report(req.query);

    let data = await report.getReport(format);

    if("json" == format){
        res.json( data );
    }
    else
    {
        res.setHeader("Content-Type", "text/csv");
		res.setHeader("Content-Disposition", "attachment;filename=\"" + reportName + ".csv\""); 
        res.send(data);
    }

};