const { app } = require('electron');
const path = require('path');
const config = require(path.join(app.getAppPath(), "config.json"));

const OnlineServiceExecutor = require("../models/OnlineServiceExecutor");

exports.service = async function (req, res) {

    var json = req.query.json || req.body.json;

    if (json == null) {
        res.send({ "error": "Invalid Request. JSON required!" });
    }
    else {

        json = JSON.parse(json);

        let url = req.url;
        let requestURI = url.split("?")[0];

        let serverURL = config["server-address"];

        OnlineServiceExecutor.execute( requestURI, json ).then( async function(result){

            if("/service/BP/create" == (requestURI))
            {
                console.log(`Updating BP[${result["id"]}]`);
                const Database = require('../database/database');
                await Database.put("bp", result, "id");
            }

            res.json(result);

        }).catch(function(error){

            res.status(500).send(error);

        });
    }
};