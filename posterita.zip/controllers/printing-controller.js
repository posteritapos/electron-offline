const printer = require('node-printer');
const net = require('net');

exports.printing = async function(request, response) {

	try {

		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
		response.setHeader("Access-Control-Allow-Headers", "X-Requested-With, Content-Type, X-Codingpedia");

		let action = request.method == 'GET' ? request.query.action : request.body.action;

		if (action == "getPrinters") {

			let result = await getPrinters();
			response.json(result);

		} else if (action == "print") {

			//console.log(request.body);

			let job = request.body.job;
			let printer = request.body.printer;

			let buff = Buffer.from(job, 'base64');
			job = buff.toString('ascii');

			let result = await print(printer, job);
			response.json(result);

		} else if (action == "ip-print") {

			let job = request.body.job;
			let hostname = request.body.ip;

			let buff = Buffer.from(job, 'base64');
			job = buff.toString('ascii');

			console.log(`Connecting to: ${hostname}`);

			//send to socket
			let socket = new net.Socket();

			socket.connect(9100, hostname, function() {
				//console.log(`Connected to: ${hostname} Job:${job}`);
				//socket.write(job);
				socket.write(buff, function() {
					response.json({
						"sent": true,
						"ip": hostname,
						"port": 9100
					});
				});

				socket.destroy();
			});

			socket.on('data', function(data) {
				console.log('Received: ' + data);
				socket.destroy(); // kill client after server's response
			});

			socket.on('error', function(error) {
				console.log('Received: ' + error);
				socket.destroy(); // kill client after server's response
				response.json(error);
			});

			socket.on('close', function() {
				console.log('Connection closed');
			});

		} else {
			response.json("Invalid action: " + action);
		}



	} catch (error) {
		console.log(error);
		response.status(500).json(error);
	}



	function print(printerName, printData) {

		const promise = new Promise(function(resolve, reject) {

			printer.printDirect({
				'data': printData,
				printer: printerName,
				type: 'RAW',
				success: function(jobID) {
					console.log("sent to printer with ID: " + jobID);
					resolve({
						"sent": true
					});
				},
				error: function(err) {
					console.log(err);
					reject("Failed to print : " + error);
				}
			});
		});

		return promise;

	}

	function getPrinters() {

		const promise = new Promise(function(resolve) {

			let printers = printer.getPrinters().map(x => x.name);
			resolve(printers);

		});

		return promise;
	}

};