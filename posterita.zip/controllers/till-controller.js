const Till = require('../models/Till');
const CashierControl = require('../models/CashierControl');

exports.till = async function (req, res) {

    var json = req.query.json;

    if (json == null) {
        res.send({ "error": "Invalid Request" });
    }
    else {
        json = JSON.parse(json);

        let action = json['action'];

        if (action == undefined) {
            res.json({ "error": "Invalid Request. Missing parameter action" });
            return;
        }

        let terminal_id = json["terminal_id"];

        if (terminal_id == undefined) {
            res.json({ "error": "Invalid Request. Missing parameter terminal_id" });
            return;
        }

        if ("open" == (action) || "close" == (action) || "saveCashierControl" == (action)) {

            let user_id = json["user_id"];

            if (user_id == undefined) {
                res.json({ "error": "Invalid Request. Missing parameter user_id" });
                return;
            }

            let date = json["date"];

            if (date == undefined) {
                res.json({ "error": "Invalid Request. Missing parameter date" });
                return;
            }

            let result;

            try {
                if ("open" == (action)) {

                    let float_amount = json["float_amount"];

                    // open
                    if (float_amount == undefined) {
                        res.json({ "error": "Invalid Request. Missing parameter float_amount" });
                        return;
                    }

                    result = await Till.open(terminal_id, user_id, date, float_amount);
                }
                else if ("saveCashierControl" == (action)) {

                    let cash_amount_entered = json["cash_amount_entered"];
                    let externalcard_amount_entered = json["externalcard_amount_entered"];

                    // saveCashierControl
                    if (cash_amount_entered == undefined) {
                        res.json({ "error": "Invalid Request. Missing parameter cash_amount_entered" });
                        return;
                    }

                    if (externalcard_amount_entered == undefined) {
                        res.json({ "error": "Invalid Request. Missing parameter externalcard_amount_entered" });
                        return;
                    }

                    // get current money in terminal			
                    let payments = await Till.getTenderAmounts(terminal_id);	
                    let cash_amount_actual = payments["cash"];
                    let externalcard_amount_actual = payments["ext_card"]; 

                    result = await CashierControl.save(date, user_id, terminal_id, cash_amount_entered, externalcard_amount_entered, cash_amount_actual, externalcard_amount_actual);
                }
                else {
                    let balance = json["balance"];
                    let external_card_amount = json["external_card_amount"];

                    // close
                    if (balance == undefined) {
                        res.json({ "error": "Invalid Request. Missing parameter balance" });
                        return;
                    }

                    if (external_card_amount == undefined) {
                        res.json({ "error": "Invalid Request. Missing parameter external_card_amount" });
                        return;
                    }

                    let syncDraftAndOpenOrders = json["syncDraftAndOpenOrders"] | false;
                    result = await Till.close(terminal_id, user_id, balance, external_card_amount, date, syncDraftAndOpenOrders);
                }

                res.json(result);
                return;
            }
            catch (e) {
                // TODO Auto-generated catch block
                res.json({"error": e.message });
                return;
            }

        }
        else if ("isOpen" == (action) || "isClose" == (action)) {

            if ("isOpen" == (action)) {
                let isOpen = await Till.isOpen(terminal_id);
                res.json({ "isopen": isOpen });
                return;
            }
            else {
                let isClose = await Till.isClose(terminal_id);
                res.json({ "isclose": isClose });
                return;
            }
        }
        else if ("validateCashAmount" == (action)) {

            let cash_amount = json["cash_amount"];

            if (!cash_amount) {
                res.json({ "error": "Invalid Request. Missing parameter cash_amount" });
                return;
            }

            let expectedCashAmount = cash_amount;

            let isValid = await Till.validateCashAmount(terminal_id, expectedCashAmount);

            res.json({ "isvalid": isValid });
            return;
        }
        else if ("getTenderAmounts" == (action)) {

            let amts = await Till.getTenderAmounts(terminal_id);
            res.json(amts);
            return;
        }
        else {
            res.json({ "error": "Invalid Request" });
            return;
        }

    }

};