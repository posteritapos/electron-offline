exports.service = function (req, res) {

    try {

      res.send("service");

    } catch (error) {

      res.send(error);
    }

  };