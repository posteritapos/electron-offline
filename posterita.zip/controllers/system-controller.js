const Application = require("../models/Application");

module.exports = async function (req, res) {

  try {

    var json = req.query.json || req.body.json;

    if (json == null) {
      throw new Error("Invalid Request. JSON required!");
    }
    else {

      json = JSON.parse(json);

      let action = json['action'];
      let result;

      if (action == undefined) {
        throw new Error("Invalid Request. Missing parameter action");
      }

      if("sendErrorLog" == action){
				
				let sent = Application.sendErrorLog();
				
				if(!sent){
					throw new Error("Failed to send error log");
        }
        
        result = {"sent" : "true"};
			}
			else if("systemInfo" == action){
				
				result = await Application.getSystemInfo();
				
			}
			else if("serverStatus" == action){
				
				result = Application.getServerStatus();
				
			}
			else if( "rePrint" == action || "openDrawer" == action || "cartLog" == action){

        let terminal_id = json['terminal_id'];
        let user_id = json['user_id'];
				
				if(terminal_id == undefined){
          throw new Error("Invalid Request. Missing parameter terminal_id");
        }
        
        if(user_id == undefined){
          throw new Error("Invalid Request. Missing parameter user_id");
				}
				
				if("rePrint" == action){

          let date_printed = json['date_printed'];
          let order_id = json['order_id'];

          if(date_printed == undefined){
            throw new Error("Invalid Request. Missing parameter date_printed");
          }

          if(order_id == undefined){
            throw new Error("Invalid Request. Missing parameter order_id");
          }
          
          const RePrint = require("../models/RePrint");
					result = await RePrint.print(date_printed, user_id, terminal_id, order_id);
					
				}
				else if("openDrawer" == action){

          let date_opened = json["date_opened"];
          let reason = json["reason"];

          if(date_opened == undefined){
            throw new Error("Invalid Request. Missing parameter date_opened");
          }
          
          const OpenDrawer = require("../models/OpenDrawer");
					result = await OpenDrawer.open(date_opened, user_id, terminal_id, reason);
				}
				else if("cartLog" == action){

          let date_logged = json["date_logged"];
					
					if(date_logged == undefined){
            throw new Error("Invalid Request. Missing parameter date_logged");
          }
          
          let { event, qty, amount, description } = json;
          
          const CartLog = require("../models/CartLog");
					result = await CartLog.log(date_logged, user_id, terminal_id, event, qty, amount, description);
				}					
				else
				{
					throw new Error("Invalid Request");
				}
				
			}
			else if("setLogLevel" == action){
        
        let level = json["level"];

				if(level == undefined){
          throw new Error("Invalid Request. Missing parameter level");
        }
        /*
				Logger l = Logger.getRootLogger();
				
				if( level.equalsIgnoreCase("debug")) {
					
					l.setLevel(Level.DEBUG);
					
				}
				else if( level.equalsIgnoreCase("info") ) {
					
					l.setLevel(Level.INFO);
					
				}
				else
				{
					l.setLevel(Level.WARN);
        }
        */
				
				result = {"set" : "true", "level" : level};
			}
			else if("resetFailedOrders" == action) {
        
        const Database = require("../database/database");
				let count = await Database.executeUpdate("update orders set status = '', error_message = null where status = 'ER'", []);
				
				result = {"updated" : count};
				
			}
			else {
        result = { "error": "Invalid Request" };
      }

      res.json(result);

    }

  } catch (error) {

    res.json({ "error": error.message });
  }

};