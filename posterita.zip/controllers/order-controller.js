const Database = require("../database/database");

exports.history = async function (req, res) {

    try 
    {
        let displaystart = req.query.iDisplayStart;
		let displaylength = req.query.iDisplayLength;
		let sEcho = req.query.sEcho;
		
		let searchTerm = "";
		
		if(req.query.sSearch != null) {
			searchTerm = req.query.sSearch;
			searchTerm = searchTerm.trim();
		}
		
		let whereClause = "";
		
		let dateFrom = req.query.dateFrom;
		let dateTo = req.query.dateTo;
        
		if( dateFrom && dateTo ) {
			
			if(whereClause.length == 0){
				whereClause += " where ";
			}
			else{
				whereClause += " and ";
			}
			
			whereClause += (` DATE_ORDERED between '${dateFrom} 00:00:00' and '${dateTo} 23:59:59' `);
		}
		else
		{
			if(dateFrom){
				
				if(whereClause.length == 0){
					whereClause += (" where ");
				}
				else{
					whereClause += (" and ");
				}
				
				whereClause += (`DATE_ORDERED >= '${dateFrom} 00:00:00' `);
			}
			else if(dateTo)
			{
				if(whereClause.length == 0){
					whereClause += (" where ");
				}
				else{
					whereClause += (" and ");
				}
				
				whereClause += (`DATE_ORDERED <= '${dateTo} 23:59:59' `);
			}
		}
		
		let docStatus = req.query.docStatus;
		if(docStatus){
			
			if(whereClause.length == 0){
				whereClause += (" where ");
			}
			else{
				whereClause += (" and ");
			}
			
			whereClause += (` DOCSTATUS = '${docStatus}' `);
		}
		
		let documentNo = req.query.documentNo;
		if(documentNo){
			
			if(whereClause.length == 0){
				whereClause += (" where ");
			}
			else{
				whereClause += (" and ");
			}
			
			whereClause += (` DOCUMENTNO = '${documentNo}' `);
		}
		
		let paymentRule = req.query.paymentRule;
		if(paymentRule){
			
			if(whereClause.length == 0){
				whereClause += (" where ");
			}
			else{
				whereClause += (" and ");
			}
			
			whereClause += (` TENDERTYPE = '${paymentRule}' `);
		}
		
		let customerId = req.query.customerId;
		if(customerId){
			
			if(whereClause.length == 0){
				whereClause += (" where ");
			}
			else{
				whereClause += (" and ");
			}
			
			whereClause += (` CUSTOMER_ID = ${customerId} `);
		}
		
		let salesRepId = req.query.salesRepId;
		if(salesRepId){
			
			if(whereClause.length == 0){
				whereClause += (" where ");
			}
			else{
				whereClause += (" and ");
			}
			
			whereClause += (` USER_ID = ${salesRepId} `);
		}
		
		let count = 0;
		
		let json = {};
		let jsonArray = [];
		
		try 
		{
            
            /*
			rs = Database.getSqlValue("select count(1) from orders " + whereClause);
			if(rs.next()){
				count = rs.getInt(1);
			}
			rs.close();
			
			rs = stmt.executeQuery("select value from orders " + whereClause.toString() +  " order by date_ordered desc OFFSET " + displaystart + " ROWS FETCH NEXT " + displaylength + " ROWS ONLY");
			
			while(rs.next())
			{
				jsonArray.put(new JSONObject(rs.getString(1)));
            }
            */

			let result = await Database.getSqlValue("select count(1) count from orders " + whereClause);
			count = result.count;

            let results = await Database.getSqlValues("select value from orders " + whereClause + " order by date_ordered desc limit " + displaylength + " offset " + displaystart);
            
			let data = [];

			results.forEach(element => {
				data.push(JSON.parse(element.value));
			});
			
			res.json({
                "sEcho" : sEcho,
			    "data" : data,
			    "draw" : 1,
			    "recordsTotal" : count,
			    "recordsFiltered" : count
            });
			
		} 
		catch (e) 
		{
            /*
			log.error(e);
			
			try 
			{
				JSONObject error = new JSONObject();
				error.put("error", e.getMessage());
				response.getWriter().write(error.toString());
			} 
			catch (Exception e1) 
			{
				log.error(e1);
            }
            */

           res.send(e);
		}

    } catch (error) {

        res.send(error.message);
    }

  };