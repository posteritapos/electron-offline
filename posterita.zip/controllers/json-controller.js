const Database = require("../database/database");
//const Order = require("../models/Order");
const Order2 = require("../models/Order2");

exports.all = function (req, res) {

  var table = req.params.table;

  console.log(`Get all records from table [${table}]`);

  Database.getAll(table).then(function (rows) {

    res.json(rows);

  }).catch(function (error) {
    res.status(500).json({"error" : error.message});
  });

};

exports.id = function (req, res) {

  var table = req.params.table;
  var id = req.params.id;

  console.log(`Get record [${id}] from table [${table}]`);

  Database.get(table, id).then(function (row) {

    res.json(row);

  }).catch(function (error) {
    res.status(500).json({"error" : error.message});
  });

};

exports.post = async function (req, res) {

  var table = req.params.table;

  var json = req.body.json;

  if (json == null) {
    res.status(404).send('Invalid json');
    return;
  }

  try {

    json = JSON.parse(json);

    if ("orders" == table) {      
      let result = await Order2.save(json);
      res.json(result);
    }
    else {
      await Database.put(table, json, "id");
      res.json(json);
    }

  } catch (error) {
    res.json({"error" : error.message});
  }

};