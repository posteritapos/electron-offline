const synchronizer = require("../database/database-synchronizer");
const NetworkUtils = require("../util/NetworkUtils");

exports.synchronize = async function(req, res) {

	try {

		let isSSEMode = false;
		let _sendUpdateFn = null;

		if (typeof(req.query.sse) != "undefined") {

			let count = 0;
			isSSEMode = true;

			res.set({
				'Cache-Control': 'no-cache',
				'Content-Type': 'text/event-stream',
				'Connection': 'keep-alive'
			});
			res.flushHeaders();

			_sendUpdateFn = function(event, data) {

				count++;
				let msg = `id:${count}\n`;
				msg += `event:${event}\n`;
				msg += `data:${data}\n\n`;

				res.write(msg);

			};

			synchronizer.addListener(function(s) {
				_sendUpdateFn("progress", s);
			});

			_sendUpdateFn("start", "");

		}

		var json = req.query.json || req.body.json;

		if (json == null) {
			throw new Error("Invalid Request. JSON required!");
		} 
		else 
		{
			json = JSON.parse(json);

			let action = json['action'];

			if (action == undefined) {
				throw new Error("Invalid Request. Missing parameter action");
			}

			let result = {
				"synchronized": true
			};
			
			//check if server reachable
			let isServerReachable = await NetworkUtils.isServerReachable();
				
			if(!isServerReachable){
				result = {
					"error" : "Server is unreachable!",
					"synchronized" : false
				};
			}
			else
			{
				await _execute(action).then( data => {
				
					result = data;
					
				}).catch(e => {
					
					result = {
						"error" : e,
						"synchronized" : false
					};
					
				});
			}
			

			if (isSSEMode) {
				_sendUpdateFn("done", JSON.stringify(result));
				return res.end("SSE");
			}

			res.json(result).end();

		}

	} catch (error) {

		console.log(error);
		res.json({
			"error": error.message
		}).end();
	}

};

async function _execute(action){
	
	if ("ordersAndDocumentNo" == action) {
		await synchronizer.synchronizeDocumentNo(true);
		await synchronizer.synchronizeOrders(false, 0, false);
	} 
	else if ("orders" == action) {
		await synchronizer.synchronizeOrders(false, 0, false);
	} 
	else if ("documentNo" == action) {
		await synchronizer.synchronizeDocumentNo(true);
	} 
	else if ("clockInOut" == action) {
		await synchronizer.synchronizeClockInOut();
	} 
	else if ("closeTill" == action)	{
		await synchronizer.synchronizeCloseTill();
	} 
	else if ("data" == action) {
		await synchronizer.pullData();
	} 
	else if ("pos" == action) {
		await synchronizer.synchronizeDocumentNo(true);
		await synchronizer.synchronizeOrders(false, 0, false);
		await synchronizer.synchronizeClockInOut();
		await synchronizer.synchronizeCloseTill();
		await synchronizer.pullData();
	} 
	else 
	{
		return {
			"error": "Invalid Request"
		};
	}
	
	return {
		"synchronized": true
	};
}
