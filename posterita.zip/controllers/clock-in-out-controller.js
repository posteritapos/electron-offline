const ClockInOut = require('../models/ClockInOut');

exports.clockInOut = async function (req, res) {   

    var json = req.query.json;

    if (json == null) {
      res.send({"error" : "Invalid Request"});
    }
    else {
      json = JSON.parse(json);

      if (json.action == undefined) {
        res.send({"error" : "Invalid Request. Missing parameter action"});
        return;
      }

      var action = json.action;

      if (json["terminal_id"] == undefined) {
        res.send({"error" : "Invalid Request. Missing parameter terminal_id"});
        return;
      }

      var terminal_id = json["terminal_id"];

      if ("clockIn" == (action) || "clockOut" == (action)) {

        if (json["user_id"] == undefined) {
          res.send({"error" : "Invalid Request. Missing parameter user_id"});
        }

        var user_id = json["user_id"];

        try {
          if ("clockIn" == action) {

            // clock in
            var time_in = json["time_in"];

            if (time_in == undefined) {
              res.send({"error" : "Invalid Request. Missing parameter time_in"});
              return;
            }

            var x = await ClockInOut.clockIn(terminal_id, user_id, time_in);

          }
          else {
            // clock out
            var time_out = json["time_out"];

            if (time_out == undefined) {
              res.send({"error" : "Invalid Request. Missing parameter time_out"});
              return;
            }

            var x = await ClockInOut.clockOut(terminal_id, user_id, time_out);
            
          }

          var clockInUserList = await ClockInOut.getClockedInUsers(terminal_id);

          var list = {
            "clockedInUserList": clockInUserList
          };

          res.json(list);

        }
        catch (e) {
          console.log(e);
          res.send(e);

        }

      }
      else if ("getClockedInUsers" == (action)) {

        var clockInUserList = await ClockInOut.getClockedInUsers(terminal_id);

        res.json(clockInUserList);
      }
      else if ("clockOutAll" == (action)) {

        // clock out
        var time_out = json["time_out"];

        await ClockInOut.clockOutAll(terminal_id, time_out);

        res.json({});
      }
      else {
        res.send({"error" : "Invalid Request"});
      }
    }

  };