const Database = require("../database/database");
const moment = require("moment");

class DailyItemSalesReport {

    constructor(params){
        this.params = params;
    }
    
    async getReport(format) {

        const sql = "select ordertype, value from orders where docstatus = 'CO' and date_ordered > ? ";
        let date = moment().format('YYYY-MM-DD') + " 00:00:00";

        let orders = await Database.getSqlValues(sql, [date]);

        if (orders.length == 0) {
            return [];
        }

        let reportJSON = await this.build(orders);
        reportJSON.sort((a, b) => {

            let nameA = a.name;
            let nameB = b.name;

            if (nameA < nameB) {
                return -1;
              }
              if (nameA > nameB) {
                return 1;
              }
            
              // names must be equal
              return 0;
        });

        if("csv" == format){

            const headers = ["barcode", "item", "description", "qty", "primarygroup", "group1", "group2", "group3", "group4", "group5", "group6", "group7", "group8"];

            let csvData = "";

            for(let i=0; i<headers.length; i++){
					
                csvData += ("\"" + headers[i] + "\",");
                
            }
            
            csvData += ("\n");

            let record;
            for(let j=0; j<reportJSON.length; j++) {
					
                record = reportJSON[j];

                csvData += ("\"" + record.barcode + "\",");
                csvData += ("\"" + record.item + "\",");
                csvData += ("\"" + record.description + "\",");
                csvData += ("\"" + record.qty + "\",");
                csvData += ("\"" + record.primarygroup + "\",");
                csvData += ("\"" + record.group1 + "\",");
                csvData += ("\"" + record.group2 + "\",");
                csvData += ("\"" + record.group3 + "\",");
                csvData += ("\"" + record.group4 + "\",");
                csvData += ("\"" + record.group5 + "\",");
                csvData += ("\"" + record.group6 + "\",");
                csvData += ("\"" + record.group7 + "\",");
                csvData += ("\"" + record.group8 + "\",");
                
                csvData += ("\n");
            }

            return csvData;
        }

        return reportJSON;

    }

    async build(records) {

        let record, ordertype;
        let order, orderline, orderlines;
        let negate;
        let value;
        let productName;
        let m_product_id;
        let qty;

        let productQtyMap = {};
        let productQtyMapEntry;

        for (let i = 0; i < records.length; i++) {

            record = records[i];

            ordertype = record["ordertype"];

            if ("POS Order" == ordertype) {
                negate = 1;
            }
            else {
                negate = -1;
            }

            value = record["value"];

            order = JSON.parse(value);
            orderlines = order.lines;

            for (let j = 0; j < orderlines.length; j++) {

                orderline = orderlines[j];
                m_product_id = orderline["id"];
                qty = orderline["qtyEntered"] * negate;
                productName = orderline["productName"];

                productQtyMapEntry = productQtyMap[productName];

                if (productQtyMapEntry == null) {

                    productQtyMapEntry = {};

                    let product = await Database.getSqlValue("select VALUE value from product where id = ?", [m_product_id]);

                    if (!product) {
                        console.log(`Product ${productName} not found!`);
                        continue;
                    }

                    product = product["value"];
                    product = JSON.parse(product);

                    productQtyMapEntry.item = product.name;
                    productQtyMapEntry.description = product.description;
                    productQtyMapEntry.barcode = product.upc;
                    productQtyMapEntry.primarygroup = product.primarygroup;
                    productQtyMapEntry.group1 = product.group1;
                    productQtyMapEntry.group2 = product.group2;
                    productQtyMapEntry.group3 = product.group3;
                    productQtyMapEntry.group4 = product.group4;
                    productQtyMapEntry.group5 = product.group5;
                    productQtyMapEntry.group6 = product.group6;
                    productQtyMapEntry.group7 = product.group7;
                    productQtyMapEntry.group8 = product.group8;
                    productQtyMapEntry.qty = 0;

                    productQtyMap[productName] = productQtyMapEntry;
                }

                productQtyMapEntry.qty += qty;

            } //for

        }

        return Object.values(productQtyMap);
    }
}

module.exports = DailyItemSalesReport;