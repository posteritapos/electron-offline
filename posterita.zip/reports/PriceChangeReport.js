const Database = require("../database/database");

class PriceChangeReport {

    constructor(params){

    }
    
    async getReport() {
        const sql = " select date_updated, name, description, upc, sku, old_price, new_price from PRODUCT_UPDATED order by date_updated desc";

        let records = await Database.getSqlValues(sql, []);

        if (records.length == 0) {
            return [];
        }

        return await this.build(records);
    }

    async build(records) {

        let headers = [
            "Date Updated",
            "Name",
            "Description",
            "UPC",
            "SKU",
            "Old Price",
            "New Price"
        ];

        let report = "";

        for(let i=0; i<headers.length; i++){

            if(i > 0) report += ",";
				
            report += "\"" + headers[i] + "\"";            
        }

        report += "\n";

        let record = null;
        for(let j=0; j<records.length; j++){
            record = records[j];

            report += `"${record.date_updated}","${record.name}","${record.description}","${record.upc}","${record.sku}","${record.old_price}","${record.new_price}"\n`;
        }

        return report;

    }
}

module.exports = PriceChangeReport;