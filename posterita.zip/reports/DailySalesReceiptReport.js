const Database = require("../database/database");

class DailySalesReceiptReport {

    constructor(params){

        this.dateFrom = null;
		this.dateTo = null;

        if(params){
            if(params.dateFrom) this.dateFrom = params.dateFrom;
            if(params.dateTo) this.dateTo = params.dateTo;
        }
    }
    
    async getReport() {

        let sql = "select value from orders ";
        
        if(this.dateFrom != null && this.dateTo != null && this.dateFrom.length > 0 && this.dateTo.length > 0) {

            sql += ` where date_ordered between '${this.dateFrom} 00:00:00' and '${this.dateTo} 23:59:59'`;
		}
		else
		{
			if(this.dateFrom != null && this.dateFrom.length > 0){				
				
				sql += ` where date_ordered >= '${this.dateFrom} 00:00:00'`;
			}
			else if(this.dateTo != null && this.dateTo.length > 0)
			{	
				sql += ` where date_ordered <= '${this.dateTo} 23:59:59'`;
			}
		}

        let records = await Database.getSqlValues(sql, []);

        return await this.build(records);

    }

    async build(records) {

        let data = [];
        let record = null;

        for(let i=0; i<records.length; i++){
            record = records[i];

            data.push(JSON.parse(record.value));
        }

        return { data : data };

    }
}

module.exports = DailySalesReceiptReport;