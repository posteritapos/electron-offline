const Database = require("../database/database");
const OrderManager = require("../models/Order2");

var FixData = {
		
    fix : async function(){

        console.log('Running fix data ...');

        await this._fixDocumentNo();

    },
    
    _fixDocumentNo : async function(){
    	
    	console.log('Running fix data ...');

        let records = await Database.getSqlValues("select value from orders where status = 'ER' and error_message like '%duplicate key value violates unique constraint%'", []);

        if(records.length == 0) return true;
        
        let order, uuid, terminalId;        
        
        console.log(`Fixing document no for ${records.length} orders`);

        for(let record of records) {
        	
            order = JSON.parse(record['value']);            
            uuid = order["uuid"];
            terminalId = order["terminalId"];
            
            let terminal = await Database.getSqlValue(" select sequence_prefix, sequence_no from terminal where id = ? ",[ terminalId ]);
            if(!terminal){
                throw new Error("Data error. Failed to load terminal!");
            }
        
            let sequence_prefix = terminal["sequence_prefix"];
            let sequence_no = terminal["sequence_no"];
            new_sequence_no = sequence_no + 1;
            
            let mask = "00000000" + new_sequence_no;
            let documentNo = mask.substring(mask.length - 8);
            
            if(sequence_prefix != null)
            {
                documentNo = sequence_prefix + documentNo;
            }	

            order["documentNo"] = documentNo;
            order["offlineDocumentNo"] = documentNo;
            
            let statements = [
            	["update orders set documentno = ?, status = ?, value = ? where id = ?", [ documentNo, "RP", JSON.stringify(order), uuid ]],
            	["update terminal set sequence_no = ? where id = ?", [ new_sequence_no, terminalId ]]
            ];
            
            let results = await Database.runBatch(statements).catch(err => {
                console.error("BATCH FAILED: " + err);
            });

            console.log(results);
        }
        
        return true;
    	
    }
};

module.exports = FixData;