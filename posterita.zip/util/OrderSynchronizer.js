const DatabaseSynchronizer = require("../database/database-synchronizer");
const NetworkUtils = require("./NetworkUtils");

let OrderSynchronizer = {

    stopFlag : false,

    state: "IDLE",

    promiseHandle : null,

    timeoutHandle : null,
    
    frequency : 5,

    start : function(frequency = 5){
		
		this.frequency = frequency;

        console.log(`Starting sync order scheduler with frequency set to ${this.frequency}m ..`);

        this.promiseHandle = new Promise((resolve) => {
			
			OrderSynchronizer.xxx = resolve;

            const INTERVAL = frequency*60*1000;

            var sync = async function(){

                OrderSynchronizer.state = "RUNNING";

                if(OrderSynchronizer.stopFlag == true){
    
                    OrderSynchronizer.state = "STOPPED";
                
                    console.log('OrderSynchronizer: stopping scheduler ..');
                    resolve();
                    return;
                }
                
                //check if server is up
				let isServerReachable = await NetworkUtils.isServerReachable();
				
				if(isServerReachable){
					await OrderSynchronizer._pushOrder();
				} 
				else
				{
					console.log("OrderSynchronizer: Failed to sync! Server is unreachable!");
				}               

                OrderSynchronizer.state = "IDLE";
                
                if(OrderSynchronizer.stopFlag == true){
    
                    OrderSynchronizer.state = "STOPPED";
                
                    console.log('OrderSynchronizer: stopping scheduler ..');
                    resolve();
                    return;
                }
    
                OrderSynchronizer.timeoutHandle = setTimeout(() => {
                    sync();
                }, INTERVAL);
            };        
    
            OrderSynchronizer.timeoutHandle = setTimeout(() => {
                sync();
            }, INTERVAL);

        });

        return OrderSynchronizer.promiseHandle;

    },

    stop : function(){

        console.log("OrderSynchronizer: Received stop signal");

        if(this.state == "IDLE"){
            clearTimeout(OrderSynchronizer.timeoutHandle);
            OrderSynchronizer.xxx();
        }

        this.stopFlag = true;
        return this.promiseHandle;
    },

    _pushOrder : async function(){

		console.log("OrderSynchronizer: Pushing orders ...");
	    
	    Promise.all([
			DatabaseSynchronizer.synchronizeDocumentNo(false),
			DatabaseSynchronizer.synchronizeOrders(false, 0, true)
		]).then(function(values) {			  
	    	console.log("OrderSynchronizer: Synchronization Completed");
		}).catch(function(err){
			console.log(err);
		});
        
    }
};

module.exports = OrderSynchronizer;