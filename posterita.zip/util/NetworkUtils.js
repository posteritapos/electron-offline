const { app } = require('electron');
const axios = require('axios');
const path = require('path');

const config = require(path.join(app.getAppPath(), "config.json"));
const serverURL = config["server-address"];

var NetworkUtils = {
		isServerReachable : function(url){
			return new Promise(function(resolve, reject){				
				axios.head(url || serverURL + '/version.txt').then(function (response){
					resolve(true);
				}).catch(function (error){
					resolve(false);
				});			
			});			
		}
};

module.exports = NetworkUtils;
