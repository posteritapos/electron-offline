const DatabaseSynchronizer = require("./database/database-synchronizer")
const NetworkUtils = require("./util/NetworkUtils")
const Database = require("./database/database");
const Server = require("./server/server");
const OrderSynchronizer = require('./util/OrderSynchronizer');
const FixData = require('./util/FixData');

const posterita = {
	listner: null,

	addListner: function (fn) {
		this.listner = fn;
	},

	message: function (msg) {

		if (this.listner) {
			this.listner(msg);
		}
	},

	start: function () {

		let ref = this;

		let promise = new Promise(function (resolve, reject) {

			ref.message('Initializing database');

			Database.initialize().then(async function (result) {

				//synchronize
				//check if server is up
				let isServerReachable = await NetworkUtils.isServerReachable();

				console.log(isServerReachable ? "Connected to server. " : "Failed to connect to server!");

				//synchronize db
				var rows = await Database.getAll("TERMINAL");
				let isFirstTime = false;

				if (rows == undefined || rows.length == 0) {
					isFirstTime = true;
				}

				if (isFirstTime && !isServerReachable) {
					reject("Server unreachable!. Cannot perform fresh installation.");
					return;
				}

				try {

					if (isServerReachable) {

						ref.message("Synchronizing database ...");

						DatabaseSynchronizer.addListener(/*posterita.message*/ function (x) {
							ref.message(x);
						});

						if (isFirstTime) {

							await DatabaseSynchronizer.pullData();
							await DatabaseSynchronizer.synchronizeDocumentNo(true);
						}
						else {
							await DatabaseSynchronizer.synchronizeDocumentNo(true);
							await DatabaseSynchronizer.synchronizeOrders(false, 0, false);
							await DatabaseSynchronizer.synchronizeCloseTill();
							await DatabaseSynchronizer.synchronizeClockInOut();
							await DatabaseSynchronizer.pullData();

						}

						ref.message("Synchronization Completed");

					}

				} catch (error) {

					console.log(error);

					ref.message("Failed to synchronize database!");

					if (isFirstTime) {

						reject("Failed to synchronize database!");
						return;

					}
				}

				try {

					//Fix data
					await FixData.fix();

					//Purge data
					await Database.purgeSyncData();

				} catch (error) {
					console.error(error);
				}



				//start server
				ref.message('Starting server...');

				Server.start().then(function () {

					ref.message("Server started.");
					resolve("Server started.");

					//start schedular
					OrderSynchronizer.start();

				}).catch(function (err) {

					reject(`Failed to start server. Error: ${err}`);

				});

			}).catch(function (err) {

				ref.message('Failed to initialize database!');
				console.log(err);
				reject(err);

			});

		});

		return promise;

	},

	stop: async function () {

		let ref = this;

		//stop schedular
		await OrderSynchronizer.stop();

		//stop server
		await Server.stop();

		let promise = new Promise(async function (resolve, reject) {

			let isServerReachable = await NetworkUtils.isServerReachable();

			if (!isServerReachable) {
				resolve("Server not reachable! Cannot push data.");
				return;
			}			

			Promise.all([

				DatabaseSynchronizer.synchronizeDocumentNo(true),
				DatabaseSynchronizer.synchronizeOrders(false, 0, false),
				DatabaseSynchronizer.synchronizeCloseTill(),
				DatabaseSynchronizer.synchronizeClockInOut()

			]).then(function (values) {

				Database.close();

				ref.message("Synchronization Completed");
				resolve("Synchronization Completed");

			}).catch(function (err) {
				Database.close();
				console.log(err);
				reject(err);
			});

		});

		return promise;

	}
};

exports.posterita = posterita;

//=========================================================================