//const { ipcRenderer } = require('electron');
//const { dialog } = require('electron').remote;

let app = angular.module("app", []);

app.controller("ConfigController", function ($scope, $http, $timeout) {

    $scope.showModal = false;

    $scope.config = {
        "serverUrl": "https://my.posterita.com",
        "merchantKey": 10005349,
        "terminalKey": 10006545
    };

    $scope.save = function () {

        $scope.showModal = true;

        var url = $scope.config.serverUrl + "/OfflineDataAction.do?action=testConfiguration&merchantKey="
            + $scope.config.merchantKey + "&terminalKey=" + $scope.config.terminalKey;

        $http.get(url).then(function mySuccess(response) {

            let data = response.data;

            if (data.status == "ok") {

                var domain = data["domain"];
                var config = $scope.config;
                config["domain"] = domain;

                api.showMessageBox({
                    type: "info",
                    title: "Connection Successfull",
                    message: "Configuration saved!",
                    buttons: ["Ok"]
                }).then(function () {
                    api.saveConfig({
                        "server-address":config["serverUrl"],
                        "merchant-key":config["merchantKey"],
                        "terminal-key":config["terminalKey"],
                        "domain": config["domain"]
                    });
                });
            }
            else {
                var error = data["error-message"];

                api.showMessageBox({
                    type: "error",
                    title: "Configuration Error",
                    message: error,
                    buttons: ["Ok"]
                }).then(function () {
                    $timeout(function(){
                        $scope.showModal = false;
                    });                    
                });
            }

        }, function myError(response) {
            var error = "Failed to connect to server!";

            if (response.status == 404) {
                error += " Invalid URL.";
            }
            else if(response.status == 500){
                error += "Server error.";
            }

            api.showMessageBox({
                type: "error",
                title: "Configuration Error",
                message: error,
                buttons: ["Ok"]
            }).then(function () {
                $timeout(function(){
                    $scope.showModal = false;
                });  
            });
        });

    };

});