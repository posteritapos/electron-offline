const axios = require("axios");
const AdmZip = require("adm-zip");
let crypto = require("crypto");
const path = require("path");
const fs = require('fs');

const updater = {

    addListener: function (listener) {
        this.listener = listener;
    },

    status: function (status) {
        console.log(status);
        if (this.listener) this.listener(status);
    },

    /**
     * Check for updates
     * @param config 
     * @returns true if updated
     */
    checkForUpdates: function (update_dir_url, current_version, download_dir) {

        let updater = this;

        //check if server is reachable

        return new Promise(async function (resolve, reject) {

            try {

                let remote_version = await updater.getRemoteVersion(update_dir_url).catch(e => {
                    throw e;
                });

                console.log(remote_version);

                let updates = await updater.compareVersions(current_version, remote_version).catch(e => {
                    throw e;
                });

                console.log(updates);

                if (updates.length == 0) {
                    let msg = "App is up-to-date";
                    console.log(msg);
                    resolve(msg);
                    return;
                }

                //download files
                for (let i = 0; i < updates.length; i++) {
                    await updater.downloadAndExtract(update_dir_url, updates[i], download_dir).catch(e => {
                        throw e;
                    });
                }

                //save latest version file
                fs.writeFile(path.join(download_dir, "version.json"), JSON.stringify(remote_version, null, "   "), 'utf8', function (err) {
                    if (err) {
                        console.log(err);
                        throw new Error("An error occured while saving version.");

                    }

                    console.log("Saved version file.");

                    let msg = "Successfully applied updates";
                    console.log(msg);
                    resolve(msg);
                });

            } catch (error) {
                console.error(error);
                reject(error);
            }

        });

    },

    getRemoteVersion: function (update_dir_url) {

        return new Promise(function (resolve, reject) {

            let resource_url = update_dir_url + '/version.json';

            console.log(`Requesting version file -> ${resource_url}`);

            axios.get(resource_url).then(function (response) {
                resolve(response.data);
            })
                .catch(function (error) {
                    reject(error.cause);
                })
        });

    },

    compareVersions: function (current_version, remote_version) {

        const promise = new Promise(function (resolve, reject) {

            console.log(`Comparing versions ...`);

            if (current_version == null) {

                console.log("Failed to read version.json");

                resolve([
                    {
                        "name": "posterita",
                        "checksum": remote_version["posterita"]

                    },
                    {
                        "name": "web",
                        "checksum": remote_version["web"]
                    }
                ]);

                return;
            }


            console.log("Current version:", current_version);
            console.log("Remote version:", remote_version);

            let filesName = [];

            if (current_version["version"] != remote_version["version"]) {

                if (current_version["posterita"] != remote_version["posterita"]) {
                    filesName.push({
                        "name": "posterita",
                        "checksum": remote_version["posterita"]
                    });
                }

                if (current_version["web"] != remote_version["web"]) {
                    filesName.push({
                        "name": "web",
                        "checksum": remote_version["web"]
                    });
                }

            }

            resolve(filesName);
        });

        return promise;

    },

    downloadAndExtract: function (update_dir_url, file, download_dir) {

        let file_url = update_dir_url + "/" + file.name + ".zip";

        const promise = new Promise(async (resolve, reject) => {

            axios.get(file_url, {

                onDownloadProgress: function (axiosProgressEvent) {
                    /*{
                      loaded: number;
                      total?: number;
                      progress?: number;
                      bytes: number; 
                      estimated?: number;
                      rate?: number; // download speed in bytes
                      download: true; // download sign
                    }*/

                    updater.status(Math.round(axiosProgressEvent.progress * 100) + "% | " + Math.round(axiosProgressEvent.loaded / 1024) + " KB downloaded out of " + Math.round(axiosProgressEvent.total / 1024) + " KB.");
                },

                responseType: 'stream'

            }).then(function (response) {

                const _buf = [];

                const stream = response.data;
                stream.on("data", (chunk) => _buf.push(chunk));
                stream.on("end", () => {

                    let body = Buffer.concat(_buf);
                    let hash = crypto.createHash('md5');

                    hash.update(body, 'utf8');
                    let checksum = hash.digest('hex');

                    console.log(`Checksum ${file.name}, requested: ${file.checksum} receieved: ${checksum}`);

                    if (file.checksum != checksum) {
                        reject(`Failed to apply update: ${file_url} Error: checksum mismatch!`);
                    }

                    var zip = new AdmZip(body);

                    const dest = path.join(download_dir, file.name);

                    zip.extractAllTo(dest, true);

                    updater.status(`Successfully updated dir - ${dest}`);
                    resolve(true);

                });
                stream.on("error", (err) => reject(err));

            }).catch(function (error) {
				console.error(error);
                reject(error.message);
            });

        });

        return promise;

    }
}

module.exports = updater;