const { ipcRenderer } = require('electron');

let container = null;

ipcRenderer.on('splash-message', (event, message) => {

    if(container == null){
        container = document.getElementById("message-container");
        if(container == null){
            return;
        }
    }

    container.innerHTML = message;
})