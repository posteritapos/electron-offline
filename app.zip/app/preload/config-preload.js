const { contextBridge, ipcRenderer } = require("electron");

const API = {
    showMessageBox : (params) => {
        params.window = "configWindow";
        return ipcRenderer.invoke("showMessageBox", params);
    },
    saveConfig : (config) => ipcRenderer.send("save-configuration", config)
};

contextBridge.exposeInMainWorld("api", API);