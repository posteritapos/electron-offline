const { app, BrowserWindow, dialog, ipcMain } = require('electron')
const path = require('path')
const url = require('url')
const fs = require('fs')
const Updater = require('./app/updater')
const log = require('electron-log');
const ENV = require(path.join(app.getAppPath(), "env.json"));

console.log = log.log;

process.on('uncaughtException', function (error) {
	// Handle the error
	dialog.showMessageBox(null, {
		"message": error.toString(),
		"type": "error"
	}).then(() => {
		app.exit();
	});
});

app.on('window-all-closed', function () {
	app.quit();
});

//This method will be called when Electron has done everything
//initialization and ready for creating browser windows.
app.on('ready', function () {

	try {

		launchPosterita().catch((e) => {
			throw e;
		});

	} catch (error) {
		console.log(error);

		dialog.showMessageBox(null, {
			"message": error.toString(),
			"type": "error"
		}).then(() => {
			app.exit();
		});

	}

});

async function launchPosterita() {

	console.log("Launching posterita ...");
	console.log(`Logs path: ${app.getPath("logs")}`);
	console.log(`App path: ${app.getAppPath()}`);
	console.log(`__dirname: ${__dirname}`);

	let configFilePath = path.join(app.getAppPath(), "config.json");
	console.log(`config ${configFilePath}`);

	//1. check for configuration file
	try {
		if (fs.existsSync(configFilePath)) {
			let config = require(configFilePath);

			console.log(config);

			showSplashWindow();
		}
		else {
			console.log(`File ${configFilePath} not found!`);
			await showConfigurationWindow();
		}
	}
	catch (err) {
		console.error(err)
	}
}

/* configuration window */
let configWindow;

function showConfigurationWindow() {

	configWindow = new BrowserWindow({
		width: 450,
		height: 520,
		title: 'Configure Posterita',
		resizable: false,
		autoHideMenuBar: true,
		icon: path.join(__dirname, 'app', 'assets', 'posterita.png'),
		webPreferences: {
			//nodeIntegration: true
			preload: path.join(__dirname, 'app', 'preload', 'config-preload.js')
		}
		//frame: false
	})

	// and load the index.html of the app.

	configWindow.loadURL(url.format({
		pathname: path.join(__dirname, 'app', 'config.html'),
		protocol: 'file:',
		slashes: true
	}))

	configWindow.on('closed', function () {
		// Dereference the window object, usually you would store windows
		// in an array if your app supports multi windows, this is the time
		// when you should delete the corresponding element.
		configWindow = null;
	});

}

ipcMain.on('save-configuration', async (event, arg) => {

	await saveConfiguration(arg).catch(e => {

		dialog.showMessageBox(null, {
			"message": e.toString(),
			"type": "error"
		}).then(() => {
			app.exit();
		});

	});

	showSplashWindow();
	configWindow.close();
})

ipcMain.on('exit2', async (event, arg) => {

	app.quit();
})

function saveConfiguration(json) {

	let promise = new Promise(function (resolve, reject) {

		let location = path.join(app.getAppPath(), "config.json");

		fs.writeFile(location, JSON.stringify(json), 'utf8', function (err) {
			if (err) {
				console.log("An error occured while saving config.");
				reject(err);
			}

			console.log("Saved config file.");
			resolve(json);
		});

	});

	return promise;
}


/* configuration window */

/* splash window */
let splashWindow;

function showSplashWindow() {

	splashWindow = splash = new BrowserWindow({
		width: 550,
		height: 250,
		title: 'Posterita',
		resizable: false,
		autoHideMenuBar: true,
		icon: path.join(__dirname, 'app', 'assets', 'posterita.png'),
		webPreferences: {
			preload: path.join(__dirname, 'app', 'preload', 'splash-preload.js')
		},
		frame: false
	})

	// Open the DevTools.
	if (ENV.OPEN_DEV_TOOLS) {
		splashWindow.webContents.openDevTools({ mode: 'undocked' });
	}

	splashWindow.webContents.on('did-finish-load', async () => {

		splashMessage('Checking for updates ...');

		Updater.addListener(function (x) {
			splashMessage(x);
		});		
		
		const config = require(path.join(app.getAppPath(), "config.json"));
		
		let update_dir_url = config["server-address"] + ENV["REMOTE_DIR"];
		let download_dir = app.getAppPath();
		let current_version = null;
		
		const versionFilePath = path.join(download_dir, "version.json");
		
		if (fs.existsSync(versionFilePath)) {
			current_version = require(versionFilePath);
		}

		await Updater.checkForUpdates(update_dir_url, current_version, download_dir).then(function (x) {

			splashMessage(x);

		}).catch(function (err) {

			console.log(err);
			splashMessage('Failed to download updates!');
		});

		if (fs.existsSync(path.join(download_dir, "posterita"))
			&& fs.existsSync(path.join(download_dir, "web"))) {
			// Do nothing
		}
		else {
			//fatal error
			let error = "missing posterita or web directory";
			console.log(error);

			dialog.showMessageBox(null, {
				"message": error,
				"type": "error"
			}).then(() => {
				splashWindow.close();
				app.exit();
			});

			return;
		}

		splashMessage('Starting posterita ...');

		let { posterita } = require('./posterita');

		posterita.addListner(splashMessage);
		posterita.start().then(function (result) {

			createWindow();
			splashWindow.close();

		}).catch(function (err) {

			splashMessage('Failed to start posterita!');
			splashWindow.close();
		});


	})

	splashWindow.loadURL(url.format({
		pathname: path.join(__dirname, 'app', 'splash.html'),
		protocol: 'file:',
		slashes: true
	}))

	splashWindow.on('closed', function () {
		// Dereference the window object, usually you would store windows
		// in an array if your app supports multi windows, this is the time
		// when you should delete the corresponding element.
		splashWindow = null;
	});

}

function splashMessage(message) {
	if (splashWindow) {
		splashWindow.webContents.send('splash-message', message)
	}
}
/* splash window */

/* main window */
let mainWindow;

function createWindow() {

	// Create the browser window.
	mainWindow = new BrowserWindow({
		width: 1024,
		height: 760,
		icon: path.join(__dirname, 'app', 'assets', 'posterita.png'),
		webPreferences: {
			nodeIntegration: true,
			preload: path.join(__dirname, 'app', 'preload', 'main-preload.js')
		}
	});

	let version = require("./version.json");
	mainWindow.setTitle("Posterita " + version.version);
	mainWindow.setMenuBarVisibility(ENV.MENU_BAR);

	// and load the index.html of the app.
	//mainWindow.loadURL('file://' + __dirname + '/index.html');
	mainWindow.loadURL('http://localhost:' + ENV.PORT);

	// Open the DevTools.
	if (ENV.OPEN_DEV_TOOLS) {
		mainWindow.webContents.openDevTools();
	}

	mainWindow.on('close', async function (event) {

		let index = dialog.showMessageBoxSync(mainWindow, { type: "question", buttons: ["OK", "Cancel"], title: "Posterita POS", message: "Do you want to quit?" });

		if (index == 1) {

			event.preventDefault();

		}
		else {

			await onClose();
		}

	});

	// Emitted when the window is closed.
	mainWindow.on('closed', async function () {
		// Dereference the window object, usually you would store windows
		// in an array if your app supports multi windows, this is the time
		// when you should delete the corresponding element.   

		mainWindow = null;
	});

}

// when exiting app
async function onClose() {

	//stop scheduler

	let promise = new Promise(function (resolve, reject) {

		splashWindow = splash = new BrowserWindow({
			width: 550,
			height: 250,
			title: 'Posterita',
			resizable: false,
			autoHideMenuBar: true,
			icon: path.join(__dirname, 'app', 'assets', 'posterita.png'),
			webPreferences: {
				preload: path.join(__dirname, 'app', 'preload', 'splash-preload.js')
			},
			frame: false
		})

		splashWindow.loadURL(url.format({
			pathname: path.join(__dirname, 'app', 'splash.html'),
			protocol: 'file:',
			slashes: true
		}))

		splashWindow.on('closed', function () {
			// Dereference the window object, usually you would store windows
			// in an array if your app supports multi windows, this is the time
			// when you should delete the corresponding element.
			splashWindow = null;
		});

		splashWindow.webContents.on('did-finish-load', async () => {

			let { posterita } = require('./posterita');

			await posterita.stop().then(function (msg) {
				splashMessage(msg);
				console.log(msg);
			}).catch(function (err) {
				console.log(err);
			});

			setTimeout(() => {
				splashWindow.close();
			}, 1000);


		});

	});

	return promise;

}
/* main window */


ipcMain.handle("showMessageBox", (event, args) => {

	let window = null;

	if (args.window && args.window == 'configWindow') {
		window = configWindow;
	}

	return dialog.showMessageBox(window || null, args);

});

